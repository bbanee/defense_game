﻿part of 'tower_defense_game.dart';

class ResultOverlay extends PositionComponent {
  final TowerDefenseGame gameRef;
  final VoidCallback? onExit;
  final String title;
  final String subtitle;
  Rect? _buttonRect;

  ResultOverlay({
    required this.gameRef,
    required this.title,
    required this.subtitle,
    this.onExit,
  }) {
    priority = 5000;
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    this.size = size;
    position = Vector2.zero();
    final center = size / 2;
    _buttonRect = Rect.fromCenter(
      center: Offset(center.x, center.y + 10),
      width: 180,
      height: 36,
    );
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xCC000000);
    canvas.drawRect(size.toRect(), bgPaint);

    final panelRect = Rect.fromCenter(
      center: Offset(size.x / 2, size.y / 2 - 10),
      width: 260,
      height: 160,
    );
    final panelPaint = Paint()..color = const Color(0xFF121622);
    final panelBorder = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRRect(RRect.fromRectAndRadius(panelRect, const Radius.circular(10)), panelPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(panelRect, const Radius.circular(10)), panelBorder);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 28,
        fontWeight: FontWeight.bold,
      ),
    );
    final sub = TextPaint(
      style: const TextStyle(
        color: Color(0xFFB5B5C0),
        fontSize: 14,
      ),
    );

    final center = size / 2;
    text.render(canvas, title, center - Vector2(18, 70));
    sub.render(canvas, subtitle, center - Vector2(80, -50));

    final stat = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 13,
      ),
    );
    stat.render(
      canvas,
      'Battle Gold: ${gameRef.battleGold}',
      center - Vector2(80, -20),
    );
    stat.render(
      canvas,
      'Account Gold: ${gameRef.accountGold}',
      center - Vector2(80, 0),
    );

    _renderButton(canvas, center + Vector2(0, 10), '로비로 돌아가기');
  }

  void _renderButton(Canvas canvas, Vector2 center, String label) {
    final w = 180.0;
    final h = 36.0;
    final rect = Rect.fromCenter(center: Offset(center.x, center.y), width: w, height: h);
    final paint = Paint()..color = const Color(0xFF1B1F2A);
    final border = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), paint);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), border);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.bold,
      ),
    );
    text.render(canvas, label, Vector2(center.x - 60, center.y - 8));
  }

  bool hitTest(Vector2 worldPos) {
    if (_buttonRect == null) return false;
    return _buttonRect!.contains(Offset(worldPos.x, worldPos.y));
  }
}

class BattleHud extends PositionComponent {
  final TowerDefenseGame gameRef;
  Rect? _ruleButtonRect;
  Rect? _speedButtonRect;
  Rect? _debugButtonRect;
  Rect? _debugPanelRect;

  BattleHud({required this.gameRef}) {
    priority = 1200;
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    this.size = size;
    position = Vector2.zero();
    _ruleButtonRect = Rect.fromLTWH(8, 32, 140, 22);
    _speedButtonRect = Rect.fromLTWH(160, 32, 70, 22);
    _debugButtonRect = Rect.fromLTWH(size.x - 34, 32, 26, 22);
    _debugPanelRect = Rect.fromLTWH(size.x - 200, 60, 190, 16 * 24 + 8);
  }

  @override
  void render(Canvas canvas) {
    final barHeight = 28.0;
    final bg = Paint()..color = const Color(0xAA0B0B12);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.x, barHeight), bg);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    );
    text.render(canvas, 'Battle Gold: ${gameRef.battleGold}', Vector2(8, 6));
    text.render(
      canvas,
      'Wave ${gameRef.currentWaveIndex + 1} / ${gameRef.waves.length}',
      Vector2(140, 6),
    );
    text.render(
      canvas,
      'Account Gold: ${gameRef.accountGold}',
      Vector2(260, 6),
    );
    text.render(
      canvas,
      '적: ${gameRef.enemies.length}',
      Vector2(8, 18),
    );
    text.render(
      canvas,
      '스폰 남음: ${gameRef.spawner.remainingTotal}',
      Vector2(70, 18),
    );
    text.render(
      canvas,
      'Core HP: ${gameRef.coreHp.toInt()} / ${gameRef.coreMaxHp.toInt()}',
      Vector2(size.x - 150, 6),
    );
    if (gameRef.coreMaxShield > 0) {
      text.render(
        canvas,
        'Shield: ${gameRef.coreShield.toInt()}',
        Vector2(size.x - 150, 18),
      );
    }

    final ruleBg = Paint()..color = const Color(0xFF1B1F2A);
    final ruleBorder = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    final rect = _ruleButtonRect ?? Rect.fromLTWH(8, 32, 140, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), ruleBorder);
    final ruleText = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 11,
        fontWeight: FontWeight.bold,
      ),
    );
    ruleText.render(canvas, '타겟팅: ${_ruleLabel(gameRef.currentRule)}', Vector2(rect.left + 8, rect.top + 4));

    final speedRect = _speedButtonRect ?? Rect.fromLTWH(160, 32, 70, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(speedRect, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(speedRect, const Radius.circular(6)), ruleBorder);
    ruleText.render(
      canvas,
      '${gameRef.timeScale == 1.0 ? '1x' : '2x'}',
      Vector2(speedRect.left + 24, speedRect.top + 4),
    );

    final dbg = _debugButtonRect ?? Rect.fromLTWH(size.x - 34, 32, 26, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(dbg, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(dbg, const Radius.circular(6)), ruleBorder);
    ruleText.render(canvas, 'DBG', Vector2(dbg.left + 2, dbg.top + 4));

    if (gameRef.debugOpen) {
      _renderDebugPanel(canvas);
    }
  }

  bool hitRuleButton(Vector2 worldPos) {
    if (_ruleButtonRect == null) return false;
    return _ruleButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitSpeedButton(Vector2 worldPos) {
    if (_speedButtonRect == null) return false;
    return _speedButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitDebugButton(Vector2 worldPos) {
    if (_debugButtonRect == null) return false;
    return _debugButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitDebugPanel(Vector2 worldPos, TowerDefenseGame game) {
    if (_debugPanelRect == null) return false;
    if (!_debugPanelRect!.contains(Offset(worldPos.x, worldPos.y))) return false;
    final local = Offset(worldPos.x - _debugPanelRect!.left, worldPos.y - _debugPanelRect!.top);
    final itemH = 24.0;
    final index = (local.dy / itemH).floor();
    switch (index) {
      case 0:
        game.debugInfiniteGold = !game.debugInfiniteGold;
        return true;
      case 1:
        game.debugSpawn('grunt_basic');
        return true;
      case 2:
        game.debugSpawn('sprinter_basic');
        return true;
      case 3:
        game.debugSpawn('tank_basic');
        return true;
      case 4:
        game.debugSpawn('brute_basic');
        return true;
      case 5:
        game.debugSpawn('scout_basic');
        return true;
      case 6:
        game.debugSpawn('spitter_basic');
        return true;
      case 7:
        game.debugSpawn('armored_basic');
        return true;
      case 8:
        game.debugSpawn('swarm_basic');
        return true;
      case 9:
        game.debugSpawn('elite_basic');
        return true;
      case 10:
        game.debugSpawn('boss_basic');
        return true;
      case 11:
        game.debugLevelUpTowers();
        return true;
      case 12:
        game.debugInfiniteEnemyHp = !game.debugInfiniteEnemyHp;
        return true;
      case 13:
        game._setSpeed(1.0);
        return true;
      case 14:
        game._setSpeed(2.0);
        return true;
      case 15:
        game._setSpeed(4.0);
        return true;
      default:
        return true;
    }
  }

  void _renderDebugPanel(Canvas canvas) {
    final rect = _debugPanelRect ?? Rect.fromLTWH(size.x - 200, 60, 190, 16 * 24 + 8);
    final bg = Paint()..color = const Color(0xCC0B0B12);
    final border = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), bg);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), border);

    final items = [
      '무한 골드: ${gameRef.debugInfiniteGold ? 'ON' : 'OFF'}',
      '적 소환: Grunt',
      '적 소환: Sprinter',
      '적 소환: Tank',
      '적 소환: Brute',
      '적 소환: Scout',
      '적 소환: Spitter',
      '적 소환: Armored',
      '적 소환: Swarm',
      '적 소환: Elite',
      '적 소환: Boss',
      '타워 즉시 레벨업',
      '몹 HP 무한: ${gameRef.debugInfiniteEnemyHp ? 'ON' : 'OFF'}',
      '속도 1x',
      '속도 2x',
      '속도 4x',
    ];

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 11,
      ),
    );
    for (int i = 0; i < items.length; i++) {
      text.render(canvas, items[i], Vector2(rect.left + 8, rect.top + 4 + i * 24));
    }
  }

  String _ruleLabel(TargetingRule rule) {
    return switch (rule) {
      TargetingRule.nearest => '가까운 적',
      TargetingRule.farthestProgress => '진행도 우선',
      TargetingRule.highestHp => '높은 HP',
      TargetingRule.lowestHp => '낮은 HP',
    };
  }
}


