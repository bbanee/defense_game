﻿part of 'tower_defense_game.dart';

class TowerPicker extends PositionComponent {
  final TowerDefenseGame gameRef;
  final GridPoint cell;

  late List<_HudButtonData> buttons;

  TowerPicker({required this.gameRef, required this.cell}) {
    priority = 2000;
    buttons = [
      for (final id in kAllTowerIds)
        _HudButtonData(
          id,
          _towerLabelFromId(id),
          _towerDisplayName(id),
          _rarityColor(gameRef.towerDefs[id]?.rarity),
        ),
    ];
  }

  @override
  void onMount() {
    super.onMount();
    updateLayout();
  }

  void updateLayout() {
    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    final rows = (buttons.length / cols).ceil();
    size.setValues(
      buttonSize * cols + padding * (cols + 1),
      (buttonSize + labelHeight) * rows + padding * (rows + 1),
    );

    final cellPos = cell.toWorld(gameRef);
    final left = cellPos.x - size.x / 2;
    final top = cellPos.y - size.y - gameRef.tileSize * 0.3;

    final minX = gameRef.mapOrigin.x;
    final maxX = gameRef.mapOrigin.x + gameRef.gridWidth * gameRef.tileSize - size.x;
    final minY = gameRef.mapOrigin.y;
    final maxY = gameRef.mapOrigin.y + gameRef.gridHeight * gameRef.tileSize - size.y;

    position.setValues(
      left.clamp(minX, maxX),
      top.clamp(minY, maxY),
    );
  }

  String? hitTest(Vector2 worldPos) {
    final local = worldPos - position;
    if (local.x < 0 || local.y < 0 || local.x > size.x || local.y > size.y) {
      return null;
    }

    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    for (int i = 0; i < buttons.length; i++) {
      final row = i ~/ cols;
      final col = i % cols;
      final x = padding + col * (buttonSize + padding);
      final y = padding + row * (buttonSize + labelHeight + padding);
      final rect = Rect.fromLTWH(x, y, buttonSize, buttonSize);
      if (rect.contains(Offset(local.x, local.y))) {
        final def = gameRef.towerDefs[buttons[i].towerId];
        if (def == null) return null;
        final unlocked =
            gameRef.debugOpen || (gameRef.accountProgress.towers[def.id]?.unlocked ?? false);
        if (!unlocked) return null;
        return buttons[i].towerId;
      }
    }
    return null;
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xEE1B1B22);
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(10)), bgPaint);

    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    final labelPaint = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.bold,
      ),
    );
    final namePaint = TextPaint(
      style: const TextStyle(
        color: Color(0xFFB8C2D4),
        fontSize: 9,
      ),
    );

    for (int i = 0; i < buttons.length; i++) {
      final data = buttons[i];
      final row = i ~/ cols;
      final col = i % cols;
      final x = padding + col * (buttonSize + padding);
      final y = padding + row * (buttonSize + labelHeight + padding);
      final rect = Rect.fromLTWH(x, y, buttonSize, buttonSize);

      final paint = Paint()..color = data.color;
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), paint);
      labelPaint.render(
        canvas,
        data.label,
        Vector2(x + buttonSize / 2 - 6, y + buttonSize / 2 - 8),
      );
      namePaint.render(canvas, data.name, Vector2(x, y + buttonSize + 2));

      final def = gameRef.towerDefs[data.towerId];
      final locked = def == null
          ? true
          : !(gameRef.debugOpen ||
              (gameRef.accountProgress.towers[def.id]?.unlocked ?? false));
      if (locked) {
        final shade = Paint()..color = const Color(0xAA000000);
        canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), shade);
        final lockText = TextPaint(
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        );
        lockText.render(canvas, 'LOCK', Vector2(x + 4, y + buttonSize / 2 - 6));
      }
    }
  }
}

enum TowerAction { upgrade, sell }
enum TowerActionExtra { cycleModule }

class TowerActionPanel extends PositionComponent {
  final TowerDefenseGame gameRef;
  final GridPoint cell;
  Rect? _upgradeRect;
  Rect? _sellRect;
  Rect? _moduleRect;

  TowerActionPanel({required this.gameRef, required this.cell}) {
    priority = 2000;
  }

  @override
  void onMount() {
    super.onMount();
    updateLayout();
  }

  void updateLayout() {
    final buttonW = gameRef.tileSize * 2.4;
    final buttonH = gameRef.tileSize * 0.7;
    final padding = gameRef.tileSize * 0.2;
    size = Vector2(buttonW + padding * 2, buttonH * 3 + padding * 4);

    final cellPos = cell.toWorld(gameRef);
    final left = cellPos.x - size.x / 2;
    final top = cellPos.y - size.y - gameRef.tileSize * 0.2;

    final minX = gameRef.mapOrigin.x;
    final maxX = gameRef.mapOrigin.x + gameRef.gridWidth * gameRef.tileSize - size.x;
    final minY = gameRef.mapOrigin.y;
    final maxY = gameRef.mapOrigin.y + gameRef.gridHeight * gameRef.tileSize - size.y;

    position.setValues(
      left.clamp(minX, maxX),
      top.clamp(minY, maxY),
    );

    _upgradeRect = Rect.fromLTWH(
      padding,
      padding,
      buttonW,
      buttonH,
    );
    _sellRect = Rect.fromLTWH(
      padding,
      padding * 2 + buttonH,
      buttonW,
      buttonH,
    );
    _moduleRect = Rect.fromLTWH(
      padding,
      padding * 3 + buttonH * 2,
      buttonW,
      buttonH,
    );
  }

  Object? hitTest(Vector2 worldPos) {
    final local = worldPos - position;
    if (local.x < 0 || local.y < 0 || local.x > size.x || local.y > size.y) {
      return null;
    }
    if (_upgradeRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerAction.upgrade;
    }
    if (_sellRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerAction.sell;
    }
    if (_moduleRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerActionExtra.cycleModule;
    }
    return null;
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xEE1B1B22);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.x, size.y), const Radius.circular(8)),
      bgPaint,
    );

    final tower = gameRef.towers[cell];
    final level = tower?.state.level ?? 1;
    final upgradeCost = tower?.nextUpgradeCost ?? 0;
    final refund = tower?.sellRefund ?? 0;
    final module = tower?.state.module ?? TacticalModule.none;

    final label = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 18,
        fontWeight: FontWeight.bold,
      ),
    );

    _drawButton(canvas, _upgradeRect, '강화 (Lv$level) - $upgradeCost', const Color(0xFF2B7FFF), label);
    _drawButton(canvas, _sellRect, '매각 +$refund', const Color(0xFF9E2B2B), label);
    _drawButton(
      canvas,
      _moduleRect,
      '모듈: ${_moduleLabel(module)}',
      const Color(0xFF4A5568),
      label,
    );
  }

  void _drawButton(Canvas canvas, Rect? rect, String text, Color color, TextPaint label) {
    if (rect == null) return;
    final paint = Paint()..color = color;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), paint);
    label.render(canvas, text, Vector2(rect.left + 8, rect.top + 6));
  }

  String _moduleLabel(TacticalModule module) {
    return switch (module) {
      TacticalModule.none => '없음',
      TacticalModule.focus => '집중 사격',
      TacticalModule.overclock => '오버클럭',
      TacticalModule.range => '사거리 강화',
    };
  }
}

class GridPoint {
  final int x;
  final int y;

  const GridPoint(this.x, this.y);

  Vector2 toWorld(TowerDefenseGame game) =>
      game.mapOrigin + Vector2((x + 0.5) * game.tileSize, (y + 0.5) * game.tileSize);

  @override
  bool operator ==(Object other) => other is GridPoint && other.x == x && other.y == y;

  @override
  int get hashCode => Object.hash(x, y);
}

class UltimateFxDef {
  final ShockwaveDef? shockwave;
  final GlowDef? glow;

  const UltimateFxDef({this.shockwave, this.glow});

  UltimateFxDef merge(UltimateFxDef other) {
    return UltimateFxDef(
      shockwave: other.shockwave ?? shockwave,
      glow: other.glow ?? glow,
    );
  }

  factory UltimateFxDef.fromJson(Map<String, dynamic> json) {
    return UltimateFxDef(
      shockwave: json['shockwave'] is Map<String, dynamic>
          ? ShockwaveDef.fromJson(json['shockwave'] as Map<String, dynamic>)
          : null,
      glow: json['glow'] is Map<String, dynamic>
          ? GlowDef.fromJson(json['glow'] as Map<String, dynamic>)
          : null,
    );
  }
}

class ShockwaveDef {
  final double radiusTiles;
  final double duration;
  final double width;
  final Color color;

  const ShockwaveDef({
    required this.radiusTiles,
    required this.duration,
    required this.width,
    required this.color,
  });

  factory ShockwaveDef.fromJson(Map<String, dynamic> json) {
    return ShockwaveDef(
      radiusTiles: (json['radius'] as num?)?.toDouble() ?? 1.6,
      duration: (json['duration'] as num?)?.toDouble() ?? 0.35,
      width: (json['width'] as num?)?.toDouble() ?? 6.0,
      color: _parseHexColor(json['color']?.toString() ?? '#8BE9FF'),
    );
  }
}

class GlowDef {
  final Color color;
  final double scale;
  final double opacity;

  const GlowDef({
    required this.color,
    required this.scale,
    required this.opacity,
  });

  factory GlowDef.fromJson(Map<String, dynamic> json) {
    return GlowDef(
      color: _parseHexColor(json['color']?.toString() ?? '#8BE9FF'),
      scale: (json['scale'] as num?)?.toDouble() ?? 1.4,
      opacity: (json['opacity'] as num?)?.toDouble() ?? 0.55,
    );
  }
}

Color _parseHexColor(String value) {
  var hex = value.replaceAll('#', '');
  if (hex.length == 6) {
    hex = 'FF$hex';
  }
  final intColor = int.tryParse(hex, radix: 16) ?? 0xFFFFFFFF;
  return Color(intColor);
}


