import 'package:flutter/material.dart';

class AppPanelButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;

  const AppPanelButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Color(0xFF2D2D2D), width: 2),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        foregroundColor: const Color(0xFF222222),
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16),
            const SizedBox(width: 6),
          ],
          Text(label, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
