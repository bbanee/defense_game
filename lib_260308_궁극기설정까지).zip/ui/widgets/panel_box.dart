import 'package:flutter/material.dart';

class AppPanelBox extends StatelessWidget {
  final Widget child;
  final Color borderColor;
  final EdgeInsets padding;

  const AppPanelBox({
    super.key,
    required this.child,
    required this.borderColor,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2),
      ),
      child: child,
    );
  }
}
