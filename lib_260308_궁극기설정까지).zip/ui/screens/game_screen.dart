import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:tower_defense/domain/progress/account_progress.dart';
import 'package:tower_defense/game/tower_defense_game.dart';

class GameScreen extends StatelessWidget {
  final VoidCallback? onExit;
  final String difficultyId;
  final String stageId;
  final AccountProgress progress;

  const GameScreen({
    super.key,
    this.onExit,
    required this.difficultyId,
    required this.stageId,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: GameWidget(
          game: TowerDefenseGame(
            onExitToLobby: onExit,
            difficultyId: difficultyId,
            stageId: stageId,
            accountProgress: progress,
          ),
          backgroundBuilder: (context) => const ColoredBox(color: Color(0xFF0E0E12)),
        ),
      ),
    );
  }
}
