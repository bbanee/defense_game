﻿part of 'tower_management_screen.dart';

extension _TowerManagementScreenViewExt on _TowerManagementScreenState {
  Widget _towerGridTile(TowerDef def) {
    final p = progress.towers[def.id] ?? TowerProgress(towerId: def.id, unlocked: false);
    final rarityColor = _rarityColor(def.rarity);

    return InkWell(
      onTap: () => _openTowerDetailSheet(def),
      borderRadius: BorderRadius.circular(0),
      child: Ink(
        decoration: BoxDecoration(
          color: p.unlocked ? const Color(0xFFFDFEFF) : const Color(0xFFEDEFF5),
          border: Border.all(color: const Color(0xFF9EB1DF), width: 0.9),
          boxShadow: const [
            BoxShadow(
              color: Color(0x10000000),
              blurRadius: 2,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(3, 3, 3, 2),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 72,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [rarityColor.withOpacity(0.26), const Color(0xFFFFFFFF)],
                    ),
                    border: Border.all(color: rarityColor.withOpacity(0.6), width: 1),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(7),
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: Image.asset(
                        _towerManageImagePath(def.id),
                        fit: BoxFit.cover,
                        alignment: Alignment.center,
                        errorBuilder: (_, __, ___) => Container(
                          color: const Color(0xFFE2E8F8),
                          child: const Icon(Icons.image_not_supported, size: 18),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 3),
              Text(
                _towerDisplayNameKoMultiline(def.id),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                softWrap: true,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  height: 1.06,
                ),
              ),
              const SizedBox(height: 1),
              Text(
                'Lv.${p.level}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 9.5,
                  color: p.unlocked ? const Color(0xFF2F2F2F) : const Color(0xFF999999),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openTowerDetailSheet(TowerDef def) async {
    final p = progress.towers[def.id] ?? TowerProgress(towerId: def.id, unlocked: false);
    final lp = progress.lobbyUpgrades[def.id] ?? TowerLobbyUpgradeProgress(towerId: def.id);
    progress.towers[def.id] = p;
    progress.lobbyUpgrades[def.id] = lp;
    final maxLevel = 15;
    final maxTrackLevel = _lobbyMaxTrackLevel();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, sheetSetState) {
            final unlockCost = def.unlockShards;
            final levelUpCost = _levelUpShards(def, p.level);
            final canUnlock = !p.unlocked && p.shards >= unlockCost;
            final canLevelUp = p.unlocked && p.level < maxLevel && p.shards >= levelUpCost;
            final maxPoints = p.unlocked ? p.level.clamp(1, maxLevel) : 0;
            final usedPoints = lp.identity + lp.operations + lp.synergy;
            final remainingPoints = math.max(0, maxPoints - usedPoints);

            void applyChange(VoidCallback fn) {
              setState(fn);
              sheetSetState(() {});
            }

            return SafeArea(
              child: Container(
                margin: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFFFDFEFF), Color(0xFFE9F1FF)],
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFF93AEE8), width: 2),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x26000000),
                      blurRadius: 14,
                      offset: Offset(0, 6),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                          border: Border(
                            bottom: BorderSide(color: const Color(0xFFC8D8FA).withOpacity(0.9)),
                          ),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 98,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(13),
                                      border: Border.all(color: _rarityColor(def.rarity), width: 2),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Color(0x22000000),
                                          blurRadius: 8,
                                          offset: Offset(0, 2),
                                        ),
                                      ],
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(11),
                                      child: Image.asset(
                                        _towerManageImagePath(def.id),
                                        width: 98,
                                        height: 98,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) => Container(
                                          width: 98,
                                          height: 98,
                                          color: const Color(0xFFE2E8F8),
                                          child: const Icon(Icons.image_not_supported),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  _sheetLevelActionButton(
                                    label: (p.unlocked && p.level >= maxLevel)
                                        ? 'MAX'
                                        : '${p.shards}/${p.unlocked ? levelUpCost : unlockCost}',
                                    enabled: canUnlock || canLevelUp,
                                    onPressed: () {
                                      applyChange(() {
                                        if (!p.unlocked && canUnlock) {
                                          p.shards -= unlockCost;
                                          p.unlocked = true;
                                        } else if (p.unlocked && canLevelUp) {
                                          p.shards -= levelUpCost;
                                          p.level += 1;
                                        }
                                        progress.towers[def.id] = p;
                                      });
                                    },
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: SizedBox(
                                height: 156,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                        child: Text(
                                          _towerDisplayNameKo(def.id),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontSize: 17,
                                            fontWeight: FontWeight.w900,
                                            color: Color(0xFF21366F),
                                          ),
                                        ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: _rarityColor(def.rarity).withOpacity(0.14),
                                            borderRadius: BorderRadius.circular(999),
                                            border: Border.all(color: _rarityColor(def.rarity), width: 1.2),
                                          ),
                                          child: Text(
                                            _rarityLabelKo(def.rarity),
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: FontWeight.w800,
                                              color: _rarityColor(def.rarity),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Wrap(
                                      spacing: 6,
                                      runSpacing: 6,
                                      children: [
                                        _sheetStatChip('레벨 ${p.level}/$maxLevel'),
                                        _sheetStatChip('포인트 $remainingPoints/$maxPoints'),
                                      ],
                                    ),
                                    const Spacer(),
                                    _towerHeaderSkillIcons(def.id),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
                        child: _towerDescriptionBox(def.id),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
                        child: _towerInfoPanel(def, p, lp),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                        child: Column(
                          children: [
                            _lobbyTrackControl(
                              def: def,
                              trackId: 'identity',
                              label: _trackCardTitle(def, 'identity'),
                              level: lp.identity,
                              maxLevel: maxTrackLevel,
                              canUpgrade: p.unlocked && lp.identity < maxTrackLevel && remainingPoints > 0,
                              disabledReason: _trackDisabledReason(
                                unlocked: p.unlocked,
                                level: lp.identity,
                                maxLevel: maxTrackLevel,
                                remainingPoints: remainingPoints,
                              ),
                              onUpgrade: () {
                                applyChange(() {
                                  if (!p.unlocked || lp.identity >= maxTrackLevel || remainingPoints <= 0) {
                                    return;
                                  }
                                  lp.identity += 1;
                                  progress.lobbyUpgrades[def.id] = lp;
                                });
                              },
                            ),
                            const SizedBox(height: 8),
                            _lobbyTrackControl(
                              def: def,
                              trackId: 'operations',
                              label: _trackCardTitle(def, 'operations'),
                              level: lp.operations,
                              maxLevel: maxTrackLevel,
                              canUpgrade: p.unlocked && lp.operations < maxTrackLevel && remainingPoints > 0,
                              disabledReason: _trackDisabledReason(
                                unlocked: p.unlocked,
                                level: lp.operations,
                                maxLevel: maxTrackLevel,
                                remainingPoints: remainingPoints,
                              ),
                              onUpgrade: () {
                                applyChange(() {
                                  if (!p.unlocked || lp.operations >= maxTrackLevel || remainingPoints <= 0) {
                                    return;
                                  }
                                  lp.operations += 1;
                                  progress.lobbyUpgrades[def.id] = lp;
                                });
                              },
                            ),
                            const SizedBox(height: 8),
                            _lobbyTrackControl(
                              def: def,
                              trackId: 'synergy',
                              label: _trackCardTitle(def, 'synergy'),
                              level: lp.synergy,
                              maxLevel: maxTrackLevel,
                              canUpgrade: p.unlocked && lp.synergy < maxTrackLevel && remainingPoints > 0,
                              disabledReason: _trackDisabledReason(
                                unlocked: p.unlocked,
                                level: lp.synergy,
                                maxLevel: maxTrackLevel,
                                remainingPoints: remainingPoints,
                              ),
                              onUpgrade: () {
                                applyChange(() {
                                  if (!p.unlocked || lp.synergy >= maxTrackLevel || remainingPoints <= 0) {
                                    return;
                                  }
                                  lp.synergy += 1;
                                  progress.lobbyUpgrades[def.id] = lp;
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _lobbyTrackControl({
    required TowerDef def,
    required String trackId,
    required String label,
    required int level,
    required int maxLevel,
    required bool canUpgrade,
    required String disabledReason,
    required VoidCallback onUpgrade,
  }) {
    final key = _trackKey(def.id, trackId);
    final perLevel = _trackPerLevel(def.id, trackId);
    final cap = _trackCap(def.id, trackId);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFF0F5FF)],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFC8D7FA)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF2A468A),
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '$level/$maxLevel',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF2A468A),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 1),
                Text(
                  '레벨당 ${_formatTrackValue(perLevel, key)} | 최대 ${_formatTrackValue(cap, key)}',
                  style: const TextStyle(fontSize: 11, color: Color(0xFF4964A8)),
                ),
                if (!canUpgrade)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      disabledReason,
                      style: const TextStyle(fontSize: 11, color: Color(0xFF8A2A2A)),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 120,
            child: AppPanelButton(
              label: canUpgrade ? '강화' : '강화 불가',
              onPressed: canUpgrade ? onUpgrade : null,
            ),
          ),
        ],
      ),
    );
  }

  String _trackDisabledReason({
    required bool unlocked,
    required int level,
    required int maxLevel,
    required int remainingPoints,
  }) {
    if (!unlocked) return '잠금: 타워 해금 필요';
    if (level >= maxLevel) return '최대 레벨 도달';
    if (remainingPoints <= 0) return '포인트 부족: 타워 레벨업 필요';
    return '';
  }

  String _trackCardTitle(TowerDef def, String trackId) {
    final key = _trackKey(def.id, trackId);
    return _upgradeKeyLabel(key);
  }

  Widget _towerInfoPanel(
    TowerDef def,
    TowerProgress p,
    TowerLobbyUpgradeProgress lp,
  ) {
    final towerLevel = p.level;
    final effectiveDamage = _effectiveDamage(def, towerLevel, lp.operations);
    final damageDelta = effectiveDamage - def.baseDamage;
    final effectiveInterval = _effectiveAttackInterval(def, towerLevel, lp.operations);
    final intervalDelta = effectiveInterval - def.fireRate;
    final effectiveRange = _effectiveRange(def, towerLevel, lp.operations);
    final rangeDelta = effectiveRange - def.range;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFF3F7FF)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFC8D7FA)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _infoPill('공격타입', _attackTypeLabelKo(def.attackType)),
              _infoPill('범위유형', _rangeTypeLabelKo(def)),
              _infoPill(
                '공격력',
                '${def.baseDamage.toStringAsFixed(def.baseDamage % 1 == 0 ? 0 : 1)} (${_formatSignedValue(damageDelta)})',
              ),
              _infoPill(
                '공속',
                '${def.fireRate.toStringAsFixed(2)}s (${_formatSignedValue(intervalDelta)}s)',
              ),
              _infoPill(
                '사거리',
                '${def.range.toStringAsFixed(0)} (${_formatSignedValue(rangeDelta)})',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sheetStatChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFECF2FF),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFCAD9FB)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: Color(0xFF2C4F9D),
        ),
      ),
    );
  }

  Widget _sheetLevelActionButton({
    required String label,
    required bool enabled,
    required VoidCallback onPressed,
  }) {
    final top = enabled ? const Color(0xFF4A77E8) : const Color(0xFFBCC4D8);
    final bottom = enabled ? const Color(0xFF2E57BF) : const Color(0xFFA4ADBF);
    return SizedBox(
      height: 50,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: enabled ? onPressed : null,
          borderRadius: BorderRadius.circular(9),
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(9),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [top, bottom],
              ),
              border: Border.all(
                color: enabled ? const Color(0xFF1F3D8B) : const Color(0xFF8D95A8),
                width: 1.2,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
              child: Center(
                child: Text(
                  label,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.2,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoPill(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF1FF),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFD0DDFB)),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: Color(0xFF2A468A),
        ),
      ),
    );
  }

  Widget _towerDescriptionBox(String towerId) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFF3F7FF)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFC8D7FA)),
      ),
      child: Text(
        _towerBriefDescription(towerId),
        style: const TextStyle(
          fontSize: 12,
          color: Color(0xFF3C4F86),
          fontWeight: FontWeight.w600,
          height: 1.3,
        ),
      ),
    );
  }

  Widget _towerHeaderSkillIcons(String towerId) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Transform.translate(
          offset: const Offset(0, 6),
          child: _skillIconFrame(towerId, 1, size: 56),
        ),
        Transform.translate(
          offset: const Offset(0, 6),
          child: _skillIconFrame(towerId, 2, size: 56),
        ),
        Transform.translate(
          offset: const Offset(0, 6),
          child: _skillIconFrame(towerId, 3, size: 56),
        ),
      ],
    );
  }

  Widget _towerSkillIcons(String towerId) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFFFF), Color(0xFFF3F8FF)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFC8D7FA)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '스킬',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: Color(0xFF2A468A),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _skillIconFrame(towerId, 1),
              _skillIconFrame(towerId, 2),
              _skillIconFrame(towerId, 3),
            ],
          ),
        ],
      ),
    );
  }

  Widget _skillIconFrame(String towerId, int index, {double size = 76}) {
    return SizedBox(
      width: size,
      height: size,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.asset(
          _towerSkillIconPath(towerId, index),
          fit: BoxFit.cover,
          alignment: Alignment.center,
          errorBuilder: (_, __, ___) => Container(
            color: Colors.black,
            alignment: Alignment.center,
            child: const Icon(Icons.broken_image, color: Color(0xFF8EA4D8)),
          ),
        ),
      ),
    );
  }

}

