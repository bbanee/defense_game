import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tower_defense/data/repositories/account_progress_repository.dart';
import 'package:tower_defense/domain/progress/account_progress.dart';
import 'package:tower_defense/ui/screens/building_management_screen.dart';
import 'package:tower_defense/ui/screens/help_screen.dart';
import 'package:tower_defense/ui/screens/ranking_screen.dart';
import 'package:tower_defense/ui/screens/settings_screen.dart';
import 'package:tower_defense/ui/screens/shop_screen.dart';
import 'package:tower_defense/ui/screens/tower_management_screen.dart';
import 'package:tower_defense/ui/widgets/panel_box.dart';
import 'package:tower_defense/ui/widgets/panel_button.dart';

typedef GameScreenBuilder = Widget Function({
  required String difficultyId,
  required String stageId,
  required AccountProgress progress,
  required VoidCallback onExit,
});

class LobbyScreen extends StatefulWidget {
  final GameScreenBuilder gameScreenBuilder;

  const LobbyScreen({super.key, required this.gameScreenBuilder});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  String _difficulty = '노멀 모드';
  String _stageId = 'story_01';
  AccountProgress? _progress;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final repo = AccountProgressRepository();
    final data = await repo.load();
    if (!mounted) return;
    setState(() => _progress = data);
  }

  Future<void> _resetAllLocalData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('account_progress_json');
    await prefs.remove('settings_json');
    await prefs.remove('local_ranking_json');
    await _loadProgress();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('로컬 데이터 초기화 완료')),
    );
  }

  Future<void> _grantAllTowerShards(int amount) async {
    final progress = _progress;
    if (progress == null) return;

    for (final towerId in kTowerIds) {
      final tower = progress.towers[towerId] ??
          TowerProgress(towerId: towerId, level: 1, shards: 0, unlocked: false);
      tower.shards += amount;
      progress.towers[towerId] = tower;
    }

    await AccountProgressRepository().save(progress);
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('모든 타워 조각 +$amount 지급 완료')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final borderColor = const Color(0xFF2D2D2D);
    final bgColor = const Color(0xFFF7F6F2);
    final textColor = const Color(0xFF222222);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: Container(
                width: 360,
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  border: Border.all(color: borderColor, width: 2),
                ),
                child: Column(
                  children: [
                    _TopBar(borderColor: borderColor, progress: _progress),
                    const SizedBox(height: 16),
                    Text(
                      'TOWER   DEFENSE',
                      style: TextStyle(
                        color: textColor,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        shadows: const [
                          Shadow(color: Color(0xFF3B82F6), blurRadius: 2, offset: Offset(0, 0)),
                        ],
                        letterSpacing: 1.6,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Kingdom of Flame',
                      style: TextStyle(
                        color: textColor.withOpacity(0.7),
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 20),
                    AppPanelBox(
                      borderColor: borderColor,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.terrain, size: 18),
                          const SizedBox(width: 8),
                          Text('게임 배경 이미지', style: TextStyle(color: textColor)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Text('난이도', style: TextStyle(color: textColor)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppPanelBox(
                            borderColor: borderColor,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            child: Row(
                              children: [
                                const Icon(Icons.circle, size: 12, color: Color(0xFF27C24C)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      isExpanded: true,
                                      value: _difficulty,
                                      items: const [
                                        DropdownMenuItem(value: '이지 모드', child: Text('이지 모드')),
                                        DropdownMenuItem(value: '노멀 모드', child: Text('노멀 모드')),
                                        DropdownMenuItem(value: '하드 모드', child: Text('하드 모드')),
                                      ],
                                      onChanged: (value) {
                                        if (value == null) return;
                                        setState(() => _difficulty = value);
                                      },
                                    ),
                                  ),
                                ),
                                const Icon(Icons.arrow_drop_down),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Text('스테이지', style: TextStyle(color: textColor)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppPanelBox(
                            borderColor: borderColor,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            child: Row(
                              children: [
                                const Icon(Icons.location_on, size: 12, color: Color(0xFF5FA9FF)),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: DropdownButtonHideUnderline(
                                    child: DropdownButton<String>(
                                      isExpanded: true,
                                      value: _stageId,
                                      items: const [
                                        DropdownMenuItem(value: 'story_01', child: Text('일반 스테이지')),
                                        DropdownMenuItem(value: 'test_u_stage', child: Text('테스트 U맵')),
                                      ],
                                      onChanged: (value) {
                                        if (value == null) return;
                                        setState(() => _stageId = value);
                                      },
                                    ),
                                  ),
                                ),
                                const Icon(Icons.arrow_drop_down),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: AppPanelButton(
                        label: '게임 시작',
                        onPressed: () {
                          final difficultyId = switch (_difficulty) {
                            '이지 모드' => 'easy',
                            '노멀 모드' => 'normal',
                            '하드 모드' => 'hard',
                            _ => 'normal',
                          };
                          final progress = _progress;
                          if (progress == null) return;
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => widget.gameScreenBuilder(
                                difficultyId: difficultyId,
                                stageId: _stageId,
                                progress: progress.copy(),
                                onExit: () => Navigator.of(context).pop(),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        Expanded(
                          child: AppPanelButton(
                            label: '타워 관리',
                            icon: Icons.local_fire_department,
                            onPressed: () async {
                              final progress = _progress;
                              if (progress == null) return;
                              final updated = await Navigator.of(context).push<AccountProgress>(
                                MaterialPageRoute(
                                  builder: (_) => TowerManagementScreen(progress: progress.copy()),
                                ),
                              );
                              if (updated != null) {
                                setState(() => _progress = updated);
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppPanelButton(
                            label: '건물 관리',
                            icon: Icons.home,
                            onPressed: () async {
                              final progress = _progress;
                              if (progress == null) return;
                              final updated = await Navigator.of(context).push<AccountProgress>(
                                MaterialPageRoute(
                                  builder: (_) => BuildingManagementScreen(progress: progress.copy()),
                                ),
                              );
                              if (updated != null) {
                                setState(() => _progress = updated);
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: AppPanelButton(
                            label: '상점',
                            icon: Icons.shopping_cart,
                            onPressed: () async {
                              final progress = _progress;
                              if (progress == null) return;
                              final updated = await Navigator.of(context).push<AccountProgress>(
                                MaterialPageRoute(
                                  builder: (_) => ShopScreen(progress: progress.copy()),
                                ),
                              );
                              if (updated != null) {
                                setState(() => _progress = updated);
                              }
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppPanelButton(
                            label: '도움말',
                            icon: Icons.help_outline,
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const HelpScreen(),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: AppPanelButton(
                            label: '골드 +500 (테스트)',
                            icon: Icons.add_circle_outline,
                            onPressed: () async {
                              final progress = _progress;
                              if (progress == null) return;
                              setState(() {
                                progress.accountGold += 500;
                              });
                              await AccountProgressRepository().save(progress);
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: AppPanelButton(
                            label: '랭킹',
                            icon: Icons.emoji_events,
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const RankingScreen(),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: AppPanelButton(
                            label: '설정',
                            icon: Icons.settings,
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => SettingsScreen(
                                    debugRankingBuilder: (_) => const DebugRankingSeedScreen(),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 8,
              right: 8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  OutlinedButton.icon(
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('데이터 초기화'),
                          content: const Text('로컬 계정/설정/랭킹 데이터를 모두 초기화합니다.'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text('취소'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text('초기화'),
                            ),
                          ],
                        ),
                      );
                      if (ok == true) {
                        await _resetAllLocalData();
                      }
                    },
                    icon: const Icon(Icons.delete_forever, size: 16),
                    label: const Text('초기화'),
                  ),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    onPressed: () => _grantAllTowerShards(100),
                    icon: const Icon(Icons.auto_awesome, size: 16),
                    label: const Text('타워 조각 +100'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final Color borderColor;
  final AccountProgress? progress;

  const _TopBar({required this.borderColor, this.progress});

  @override
  Widget build(BuildContext context) {
    final gold = progress?.accountGold ?? 0;
    final diamonds = progress?.diamonds ?? 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _StatItem(icon: Icons.savings, label: '$gold'),
          _StatItem(icon: Icons.diamond, label: '$diamonds'),
          const _StatItem(icon: Icons.favorite, label: '20/20'),
          const _StatItem(icon: Icons.star, label: '5/30'),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const _StatItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}
