import 'package:flutter/material.dart';
import 'package:tower_defense/data/repositories/settings_repository.dart';
import 'package:tower_defense/ui/widgets/panel_button.dart';

class SettingsScreen extends StatefulWidget {
  final WidgetBuilder? debugRankingBuilder;

  const SettingsScreen({super.key, this.debugRankingBuilder});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool musicOn = true;
  bool sfxOn = true;
  bool showDamage = true;
  final SettingsRepository repo = SettingsRepository();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await repo.load();
    if (!mounted) return;
    setState(() {
      musicOn = data.musicOn;
      sfxOn = data.sfxOn;
      showDamage = data.showDamage;
    });
  }

  Future<void> _save() async {
    await repo.save(SettingsData(
      musicOn: musicOn,
      sfxOn: sfxOn,
      showDamage: showDamage,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('배경음악'),
            value: musicOn,
            onChanged: (v) async {
              setState(() => musicOn = v);
              await _save();
            },
          ),
          SwitchListTile(
            title: const Text('효과음'),
            value: sfxOn,
            onChanged: (v) async {
              setState(() => sfxOn = v);
              await _save();
            },
          ),
          SwitchListTile(
            title: const Text('데미지 표시'),
            value: showDamage,
            onChanged: (v) async {
              setState(() => showDamage = v);
              await _save();
            },
          ),
          const SizedBox(height: 12),
          AppPanelButton(
            label: '랭킹 샘플 생성(테스트)',
            onPressed: widget.debugRankingBuilder == null
                ? null
                : () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: widget.debugRankingBuilder!),
                    );
                  },
          ),
          const SizedBox(height: 12),
          AppPanelButton(
            label: '로비로 돌아가기',
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}
