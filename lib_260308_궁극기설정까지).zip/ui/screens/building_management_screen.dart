import 'package:flutter/material.dart';
import 'package:tower_defense/data/repositories/account_progress_repository.dart';
import 'package:tower_defense/domain/progress/account_progress.dart';
import 'package:tower_defense/ui/widgets/info_row.dart';
import 'package:tower_defense/ui/widgets/panel_button.dart';

class BuildingManagementScreen extends StatefulWidget {
  final AccountProgress progress;

  const BuildingManagementScreen({super.key, required this.progress});

  @override
  State<BuildingManagementScreen> createState() => _BuildingManagementScreenState();
}

class _BuildingManagementScreenState extends State<BuildingManagementScreen> {
  late AccountProgress progress;
  final AccountProgressRepository progressRepo = AccountProgressRepository();

  @override
  void initState() {
    super.initState();
    progress = widget.progress;
  }

  @override
  Widget build(BuildContext context) {
    final core = progress.core;
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await progressRepo.save(progress);
          if (!mounted) return;
          Navigator.of(context).pop(progress);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('건물 관리')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppInfoRow(label: '코어 레벨', value: '${core.level}'),
            AppInfoRow(label: 'HP', value: '${core.hp} (Lv${core.hpLevel})'),
            AppInfoRow(label: '실드', value: '${core.shield} (Lv${core.shieldLevel})'),
            AppInfoRow(
              label: '방어율',
              value: '${(core.defenseRate * 100).toStringAsFixed(0)}% (Lv${core.defenseLevel})',
            ),
            const SizedBox(height: 16),
            AppPanelButton(
              label: 'HP 강화 (비용 60)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 60) return;
                  progress.accountGold -= 60;
                  core.hpLevel += 1;
                  core.level += 1;
                  core.hp = (core.hp * 1.08).round();
                });
              },
            ),
            const SizedBox(height: 8),
            AppPanelButton(
              label: '실드 강화 (비용 50)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 50) return;
                  progress.accountGold -= 50;
                  core.shieldLevel += 1;
                  core.level += 1;
                  core.shield = (core.shield * 1.06).round();
                });
              },
            ),
            const SizedBox(height: 8),
            AppPanelButton(
              label: '방어율 강화 (비용 70)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 70) return;
                  progress.accountGold -= 70;
                  core.defenseLevel += 1;
                  core.level += 1;
                  core.defenseRate = (core.defenseRate + 0.01).clamp(0, 0.9);
                });
              },
            ),
            const SizedBox(height: 12),
            AppPanelButton(
              label: '로비로 돌아가기',
              onPressed: () async {
                await progressRepo.save(progress);
                if (!mounted) return;
                Navigator.of(context).pop(progress);
              },
            ),
          ],
        ),
      ),
    );
  }

}
