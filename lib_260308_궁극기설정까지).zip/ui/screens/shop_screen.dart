import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:tower_defense/data/definition_repository.dart';
import 'package:tower_defense/data/repositories/account_progress_repository.dart';
import 'package:tower_defense/domain/models/definitions.dart';
import 'package:tower_defense/domain/progress/account_progress.dart';
import 'package:tower_defense/ui/widgets/info_row.dart';
import 'package:tower_defense/ui/widgets/panel_button.dart';

const List<String> kShopTowerIds = [
  'cannon_basic',
  'rapid_basic',
  'shotgun_basic',
  'frost_basic',
  'drone_basic',
  'chain_basic',
  'missile_basic',
  'support_basic',
  'laser_basic',
  'sniper_basic',
  'gravity_basic',
  'infection_basic',
  'chrono_basic',
  'singularity_basic',
  'mortar_basic',
];

class ShopScreen extends StatefulWidget {
  final AccountProgress progress;

  const ShopScreen({super.key, required this.progress});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  late AccountProgress progress;
  final DefinitionRepository repo = DefinitionRepository();
  final AccountProgressRepository progressRepo = AccountProgressRepository();
  GachaBannerDef? banner;
  Map<String, TowerDef> towerDefs = {};
  String? lastResult;

  @override
  void initState() {
    super.initState();
    progress = widget.progress;
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedBanner = await repo.loadGachaBanner('starter');
    final defs = <String, TowerDef>{};
    for (final id in kShopTowerIds) {
      defs[id] = await repo.loadTower(id);
    }
    if (!mounted) return;
    setState(() {
      banner = loadedBanner;
      towerDefs = defs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await progressRepo.save(progress);
          Navigator.of(context).pop(progress);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('상점')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppInfoRow(label: '보유 골드', value: '${progress.accountGold}'),
            AppInfoRow(label: '보유 다이아', value: '${progress.diamonds}'),
            const SizedBox(height: 12),
            _bannerCard(),
            const SizedBox(height: 12),
            if (lastResult != null)
              Text('최근 결과: $lastResult', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            AppPanelButton(
              label: '1회 뽑기 (다이아 300)',
              onPressed: () {
                final result = _rollOnce(useCost: true);
                setState(() => lastResult = result);
              },
            ),
            const SizedBox(height: 8),
            AppPanelButton(
              label: '다이아 +500 (테스트)',
              onPressed: () async {
                setState(() => progress.diamonds += 500);
                await progressRepo.save(progress);
              },
            ),
            const SizedBox(height: 8),
            AppPanelButton(
              label: '테스트 1회 뽑기 (무료)',
              onPressed: () {
                final result = _rollOnce(useCost: false);
                setState(() => lastResult = result);
              },
            ),
            const SizedBox(height: 12),
            AppPanelButton(
              label: '로비로 돌아가기',
              onPressed: () async {
                await progressRepo.save(progress);
                if (!mounted) return;
                Navigator.of(context).pop(progress);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _bannerCard() {
    final b = banner;
    if (b == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final total = b.rates.fold<double>(0, (sum, r) => sum + r.percent);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('배너: ${b.bannerId}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...b.rates.map((r) => Text('${r.rarity}: ${r.percent}%')).toList(),
            const SizedBox(height: 6),
            Text('확률 합계: ${total.toStringAsFixed(1)}%'),
          ],
        ),
      ),
    );
  }

  String _rollOnce({required bool useCost}) {
    final b = banner;
    if (b == null) return '배너 로딩 중';
    if (useCost) {
      if (b.cost.currency == 'diamond') {
        if (progress.diamonds < b.cost.amount) {
          return '다이아 부족';
        }
        progress.diamonds -= b.cost.amount;
      } else if (b.cost.currency == 'accountGold') {
        if (progress.accountGold < b.cost.amount) {
          return '골드 부족';
        }
        progress.accountGold -= b.cost.amount;
      }
    }
    final rng = math.Random();
    final roll = rng.nextDouble() * 100;
    double acc = 0;
    String rarity = b.rates.first.rarity;
    for (final rate in b.rates) {
      acc += rate.percent;
      if (roll <= acc) {
        rarity = rate.rarity;
        break;
      }
    }

    final candidates = towerDefs.values.where((t) => t.rarity == rarity).toList();
    if (candidates.isEmpty) {
      return '획득 실패';
    }
    final tower = candidates[rng.nextInt(candidates.length)];
    final p = progress.towers[tower.id] ?? TowerProgress(towerId: tower.id, unlocked: false);
    p.shards += 5;
    progress.towers[tower.id] = p;
    return '${tower.id} 조각 +5 ($rarity)';
  }

}
