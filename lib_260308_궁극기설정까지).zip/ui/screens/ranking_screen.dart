import 'package:flutter/material.dart';
import 'package:tower_defense/data/repositories/ranking_repository.dart';
import 'package:tower_defense/ui/widgets/panel_button.dart';

class RankingScreen extends StatelessWidget {
  const RankingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('랭킹')),
      body: FutureBuilder<List<RankingEntry>>(
        future: RankingRepository().load(),
        builder: (context, snapshot) {
          final list = snapshot.data ?? const [];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Local Top 20',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (list.isEmpty)
                const Text('기록 없음')
              else
                ...list.asMap().entries.map((e) {
                  final index = e.key + 1;
                  final item = e.value;
                  return _rankRow(_RankEntry(rank: index, name: item.name, score: item.score));
                }).toList(),
            ],
          );
        },
      ),
    );
  }

  Widget _rankRow(_RankEntry entry) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('#${entry.rank}  ${entry.name}'),
            Text('${entry.score}'),
          ],
        ),
      ),
    );
  }
}

class DebugRankingSeedScreen extends StatelessWidget {
  const DebugRankingSeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('랭킹 디버그')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppPanelButton(
            label: '샘플 랭킹 추가',
            onPressed: () async {
              final repo = RankingRepository();
              await repo.addScore('NEON_AEGIS', 182340);
              await repo.addScore('CYBER_FALCON', 171220);
              await repo.addScore('GRID_HUNTER', 160880);
              await repo.addScore('ION_BLADE', 149300);
              await repo.addScore('NOVA_CORE', 141050);
            },
          ),
        ],
      ),
    );
  }
}

class _RankEntry {
  final int rank;
  final String name;
  final int score;

  const _RankEntry({required this.rank, required this.name, required this.score});
}
