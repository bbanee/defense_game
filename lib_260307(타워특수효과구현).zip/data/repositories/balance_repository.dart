﻿import 'dart:convert';
import 'package:flutter/services.dart';

class BalanceConfig {
  final PermanentGrowthConfig defaultPermanentGrowth;
  final Map<String, PermanentGrowthConfig> towerGrowthOverrides;

  const BalanceConfig({
    required this.defaultPermanentGrowth,
    required this.towerGrowthOverrides,
  });

  factory BalanceConfig.fromJson(Map<String, dynamic> json) {
    final overrides = <String, PermanentGrowthConfig>{};
    final rawOverrides = json['towerGrowthOverrides'] as Map<String, dynamic>? ?? {};
    rawOverrides.forEach((key, value) {
      overrides[key] = PermanentGrowthConfig.fromJson(value as Map<String, dynamic>);
    });

    return BalanceConfig(
      defaultPermanentGrowth: PermanentGrowthConfig.fromJson(
        json['defaultPermanentGrowth'] as Map<String, dynamic>,
      ),
      towerGrowthOverrides: overrides,
    );
  }

  PermanentGrowthConfig growthForTower(String towerId) {
    return towerGrowthOverrides[towerId] ?? defaultPermanentGrowth;
  }
}

class PermanentGrowthConfig {
  final double damagePercentPerLevel;
  final double fireRatePercentPerLevel;
  final int rangeBonusEveryLevels;
  final double rangeBonusPerStep;

  const PermanentGrowthConfig({
    required this.damagePercentPerLevel,
    required this.fireRatePercentPerLevel,
    required this.rangeBonusEveryLevels,
    required this.rangeBonusPerStep,
  });

  factory PermanentGrowthConfig.fromJson(Map<String, dynamic> json) {
    return PermanentGrowthConfig(
      damagePercentPerLevel: (json['damagePercentPerLevel'] as num).toDouble(),
      fireRatePercentPerLevel: (json['fireRatePercentPerLevel'] as num).toDouble(),
      rangeBonusEveryLevels: json['rangeBonusEveryLevels'] as int,
      rangeBonusPerStep: (json['rangeBonusPerStep'] as num).toDouble(),
    );
  }
}

class BalanceRepository {
  static const String _path = 'assets/data/balance/growth.json';

  Future<BalanceConfig> load() async {
    final raw = await rootBundle.loadString(_path);
    final json = jsonDecode(raw) as Map<String, dynamic>;
    return BalanceConfig.fromJson(json);
  }
}
