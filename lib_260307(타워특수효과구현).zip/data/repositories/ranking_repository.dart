﻿import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class RankingEntry {
  final String name;
  final int score;

  const RankingEntry({required this.name, required this.score});

  factory RankingEntry.fromJson(Map<String, dynamic> json) {
    return RankingEntry(
      name: json['name'] as String,
      score: json['score'] as int,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'score': score,
    };
  }
}

class RankingRepository {
  static const String _prefsKey = 'local_ranking_json';

  Future<List<RankingEntry>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    if (raw == null || raw.isEmpty) {
      return const [];
    }
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => RankingEntry.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> save(List<RankingEntry> entries) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(entries.map((e) => e.toJson()).toList());
    await prefs.setString(_prefsKey, raw);
  }

  Future<void> addScore(String name, int score) async {
    final entries = await load();
    final updated = [...entries, RankingEntry(name: name, score: score)];
    updated.sort((a, b) => b.score.compareTo(a.score));
    await save(updated.take(20).toList());
  }
}
