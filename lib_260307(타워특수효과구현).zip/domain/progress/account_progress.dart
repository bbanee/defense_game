﻿import 'package:tower_defense/domain/progress/core_progress.dart';

class TowerProgress {
  final String towerId;
  int level;
  int shards;
  bool unlocked;

  TowerProgress({
    required this.towerId,
    this.level = 1,
    this.shards = 0,
    this.unlocked = true,
  });

  factory TowerProgress.fromJson(Map<String, dynamic> json) {
    return TowerProgress(
      towerId: json['towerId'] as String,
      level: json['level'] as int? ?? 1,
      shards: json['shards'] as int? ?? 0,
      unlocked: json['unlocked'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'towerId': towerId,
      'level': level,
      'shards': shards,
      'unlocked': unlocked,
    };
  }

  TowerProgress copy() {
    return TowerProgress(
      towerId: towerId,
      level: level,
      shards: shards,
      unlocked: unlocked,
    );
  }
}

class AccountProgress {
  int accountGold;
  int diamonds;
  final Map<String, TowerProgress> towers;
  final CoreProgress core;

  AccountProgress({
    this.accountGold = 0,
    this.diamonds = 0,
    Map<String, TowerProgress>? towers,
    CoreProgress? core,
  })  : towers = towers ?? {},
        core = core ?? CoreProgress();

  factory AccountProgress.fromJson(Map<String, dynamic> json) {
    final towerMap = <String, TowerProgress>{};
    final rawTowers = (json['towers'] as List<dynamic>? ?? []);
    for (final item in rawTowers) {
      final progress = TowerProgress.fromJson(item as Map<String, dynamic>);
      towerMap[progress.towerId] = progress;
    }
    return AccountProgress(
      accountGold: json['accountGold'] as int? ?? 0,
      diamonds: json['diamonds'] as int? ?? 0,
      towers: towerMap,
      core: CoreProgress.fromJson(json['core'] as Map<String, dynamic>? ?? {}),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'accountGold': accountGold,
      'diamonds': diamonds,
      'towers': towers.values.map((e) => e.toJson()).toList(),
      'core': core.toJson(),
    };
  }

  AccountProgress copy() {
    final copyTowers = <String, TowerProgress>{};
    for (final entry in towers.entries) {
      copyTowers[entry.key] = entry.value.copy();
    }
    return AccountProgress(
      accountGold: accountGold,
      diamonds: diamonds,
      towers: copyTowers,
      core: core.copy(),
    );
  }
}
