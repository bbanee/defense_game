﻿import 'package:tower_defense/data/json_asset_loader.dart';
import 'package:tower_defense/domain/models/definitions.dart';

class DefinitionRepository {
  final JsonAssetLoader loader;

  const DefinitionRepository({this.loader = const JsonAssetLoader()});

  Future<TowerDef> loadTower(String id) async {
    final json = await loader.loadObject('assets/data/towers/$id.json');
    return TowerDef.fromJson(json);
  }

  Future<EnemyDef> loadEnemy(String id) async {
    final json = await loader.loadObject('assets/data/enemies/$id.json');
    return EnemyDef.fromJson(json);
  }

  Future<StageDef> loadStage(String id) async {
    final json = await loader.loadObject('assets/data/stages/$id.json');
    return StageDef.fromJson(json);
  }

  Future<DifficultyDef> loadDifficulty(String id) async {
    final json = await loader.loadObject('assets/data/difficulties/$id.json');
    return DifficultyDef.fromJson(json);
  }

  Future<ModeDef> loadMode(String id) async {
    final json = await loader.loadObject('assets/data/modes/$id.json');
    return ModeDef.fromJson(json);
  }

  Future<GachaBannerDef> loadGachaBanner(String id) async {
    final json = await loader.loadObject('assets/data/gacha/$id.json');
    return GachaBannerDef.fromJson(json);
  }

  Future<MapDef> loadMap(String id) async {
    final json = await loader.loadObject('assets/data/maps/$id.json');
    return MapDef.fromJson(json);
  }

  Future<WaveDef> loadWave(String id) async {
    final json = await loader.loadObject('assets/data/waves/$id.json');
    return WaveDef.fromJson(json);
  }
}
