﻿import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flame/sprite.dart';
import 'package:flutter/material.dart';
import 'package:tower_defense/data/definition_repository.dart';
import 'package:tower_defense/data/repositories/account_progress_repository.dart';
import 'package:tower_defense/data/repositories/balance_repository.dart';
import 'package:tower_defense/data/repositories/settings_repository.dart';
import 'package:tower_defense/data/repositories/ranking_repository.dart';
import 'package:tower_defense/domain/models/definitions.dart';
import 'package:tower_defense/domain/progress/account_progress.dart';
import 'package:tower_defense/domain/progress/core_progress.dart';

void main() {
  runApp(const TowerDefenseApp());
}

class TowerDefenseApp extends StatelessWidget {
  const TowerDefenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Tower Defense',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3B3B42)),
        fontFamily: 'Roboto',
      ),
      home: const LobbyScreen(),
    );
  }
}

class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen> {
  String _difficulty = '이지 모드';
  AccountProgress? _progress;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final repo = AccountProgressRepository();
    final data = await repo.load();
    if (!mounted) return;
    setState(() => _progress = data);
  }

  @override
  Widget build(BuildContext context) {
    final borderColor = const Color(0xFF2D2D2D);
    final bgColor = const Color(0xFFF7F6F2);
    final textColor = const Color(0xFF222222);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Center(
          child: Container(
            width: 360,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            decoration: BoxDecoration(
              border: Border.all(color: borderColor, width: 2),
            ),
            child: Column(
              children: [
                _TopBar(borderColor: borderColor, progress: _progress),
                const SizedBox(height: 16),
                Text(
                  'TOWER   DEFENSE',
                  style: TextStyle(
                    color: textColor,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.6,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Kingdom of Flame',
                  style: TextStyle(
                    color: textColor.withOpacity(0.7),
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 20),
                _PanelBox(
                  borderColor: borderColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.terrain, size: 18),
                      const SizedBox(width: 8),
                      Text('게임 배경 이미지', style: TextStyle(color: textColor)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Text('난이도', style: TextStyle(color: textColor)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PanelBox(
                        borderColor: borderColor,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        child: Row(
                          children: [
                            const Icon(Icons.circle, size: 12, color: Color(0xFF27C24C)),
                            const SizedBox(width: 8),
                            Expanded(
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  isExpanded: true,
                                  value: _difficulty,
                                  items: const [
                                    DropdownMenuItem(value: '이지 모드', child: Text('이지 모드')),
                                    DropdownMenuItem(value: '노말 모드', child: Text('노말 모드')),
                                    DropdownMenuItem(value: '하드 모드', child: Text('하드 모드')),
                                  ],
                                  onChanged: (value) {
                                    if (value == null) return;
                                    setState(() => _difficulty = value);
                                  },
                                ),
                              ),
                            ),
                            const Icon(Icons.arrow_drop_down),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: _PanelButton(
                    label: '▶  게임 시작',
                    onPressed: () {
                      final difficultyId = switch (_difficulty) {
                        '이지 모드' => 'easy',
                        '노말 모드' => 'normal',
                        '하드 모드' => 'hard',
                        _ => 'normal',
                      };
                      final progress = _progress;
                      if (progress == null) return;
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => GameScreen(
                            difficultyId: difficultyId,
                            progress: progress.copy(),
                            onExit: () => Navigator.of(context).pop(),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: _PanelButton(
                        label: '타워 관리',
                        icon: Icons.local_fire_department,
                        onPressed: () async {
                          final progress = _progress;
                          if (progress == null) return;
                          final updated = await Navigator.of(context).push<AccountProgress>(
                            MaterialPageRoute(
                              builder: (_) => TowerManagementScreen(
                                progress: progress.copy(),
                              ),
                            ),
                          );
                          if (updated != null) {
                            setState(() => _progress = updated);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PanelButton(
                        label: '건물 관리',
                        icon: Icons.home,
                        onPressed: () async {
                          final progress = _progress;
                          if (progress == null) return;
                          final updated = await Navigator.of(context).push<AccountProgress>(
                            MaterialPageRoute(
                              builder: (_) => BuildingManagementScreen(
                                progress: progress.copy(),
                              ),
                            ),
                          );
                          if (updated != null) {
                            setState(() => _progress = updated);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _PanelButton(
                        label: '상점',
                        icon: Icons.shopping_cart,
                        onPressed: () async {
                          final progress = _progress;
                          if (progress == null) return;
                          final updated = await Navigator.of(context).push<AccountProgress>(
                            MaterialPageRoute(
                              builder: (_) => ShopScreen(
                                progress: progress.copy(),
                              ),
                            ),
                          );
                          if (updated != null) {
                            setState(() => _progress = updated);
                          }
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PanelButton(
                        label: '도움말',
                        icon: Icons.help_outline,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const HelpScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _PanelButton(
                        label: '골드 +500 (테스트)',
                        icon: Icons.add_circle_outline,
                        onPressed: () async {
                          final progress = _progress;
                          if (progress == null) return;
                          setState(() {
                            progress.accountGold += 500;
                          });
                          await AccountProgressRepository().save(progress);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _PanelButton(
                        label: '랭킹',
                        icon: Icons.emoji_events,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const RankingScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PanelButton(
                        label: '설정',
                        icon: Icons.settings,
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const SettingsScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GameScreen extends StatelessWidget {
  final VoidCallback? onExit;
  final String difficultyId;
  final AccountProgress progress;

  const GameScreen({
    super.key,
    this.onExit,
    required this.difficultyId,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: GameWidget(
          game: TowerDefenseGame(
            onExitToLobby: onExit,
            difficultyId: difficultyId,
            accountProgress: progress,
          ),
          backgroundBuilder: (context) => const ColoredBox(color: Color(0xFF0E0E12)),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final Color borderColor;
  final AccountProgress? progress;

  const _TopBar({required this.borderColor, this.progress});

  @override
  Widget build(BuildContext context) {
    final gold = progress?.accountGold ?? 0;
    final diamonds = progress?.diamonds ?? 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _StatItem(icon: Icons.savings, label: '$gold'),
          _StatItem(icon: Icons.diamond, label: '$diamonds'),
          const _StatItem(icon: Icons.favorite, label: '20/20'),
          const _StatItem(icon: Icons.star, label: '5/30'),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const _StatItem({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 16),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}

class _PanelBox extends StatelessWidget {
  final Widget child;
  final Color borderColor;
  final EdgeInsets padding;

  const _PanelBox({
    required this.child,
    required this.borderColor,
    this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        border: Border.all(color: borderColor, width: 2),
      ),
      child: child,
    );
  }
}

class _PanelButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;

  const _PanelButton({required this.label, this.icon, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        side: const BorderSide(color: Color(0xFF2D2D2D), width: 2),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        foregroundColor: const Color(0xFF222222),
      ),
      onPressed: onPressed ?? () {},
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 16),
            const SizedBox(width: 6),
          ],
          Text(label),
        ],
      ),
    );
  }
}

class PlaceholderScreen extends StatelessWidget {
  final String title;

  const PlaceholderScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Text(
          '$title 화면 준비 중',
          style: const TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}

class ShopScreen extends StatefulWidget {
  final AccountProgress progress;

  const ShopScreen({super.key, required this.progress});

  @override
  State<ShopScreen> createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  late AccountProgress progress;
  final DefinitionRepository repo = DefinitionRepository();
  final AccountProgressRepository progressRepo = AccountProgressRepository();
  GachaBannerDef? banner;
  Map<String, TowerDef> towerDefs = {};
  String? lastResult;

  @override
  void initState() {
    super.initState();
    progress = widget.progress;
    _loadData();
  }

  Future<void> _loadData() async {
    final loadedBanner = await repo.loadGachaBanner('starter');
    final defs = <String, TowerDef>{};
    for (final id in kAllTowerIds) {
      defs[id] = await repo.loadTower(id);
    }
    if (!mounted) return;
    setState(() {
      banner = loadedBanner;
      towerDefs = defs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await progressRepo.save(progress);
          Navigator.of(context).pop(progress);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('상점')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _infoRow('보유 골드', '${progress.accountGold}'),
            _infoRow('보유 다이아', '${progress.diamonds}'),
            const SizedBox(height: 12),
            _bannerCard(),
            const SizedBox(height: 12),
            if (lastResult != null)
              Text('최근 결과: $lastResult', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _PanelButton(
              label: '1회 뽑기 (다이아 300)',
              onPressed: () {
                final result = _rollOnce(useCost: true);
                setState(() => lastResult = result);
              },
            ),
            const SizedBox(height: 8),
            _PanelButton(
              label: '다이아 +500 (테스트)',
              onPressed: () async {
                setState(() => progress.diamonds += 500);
                await progressRepo.save(progress);
              },
            ),
            const SizedBox(height: 8),
            _PanelButton(
              label: '테스트 1회 뽑기 (무료)',
              onPressed: () {
                final result = _rollOnce(useCost: false);
                setState(() => lastResult = result);
              },
            ),
            const SizedBox(height: 12),
            _PanelButton(
              label: '로비로 돌아가기',
              onPressed: () async {
                await progressRepo.save(progress);
                Navigator.of(context).pop(progress);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _bannerCard() {
    final b = banner;
    if (b == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final total = b.rates.fold<double>(0, (sum, r) => sum + r.percent);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('배너: ${b.bannerId}', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...b.rates.map((r) => Text('${r.rarity}: ${r.percent}%')).toList(),
            const SizedBox(height: 6),
            Text('확률 합계: ${total.toStringAsFixed(1)}%'),
          ],
        ),
      ),
    );
  }

  String _rollOnce({required bool useCost}) {
    final b = banner;
    if (b == null) return '배너 로딩 중';
    if (useCost) {
      if (b.cost.currency == 'diamond') {
        if (progress.diamonds < b.cost.amount) {
          return '다이아 부족';
        }
        progress.diamonds -= b.cost.amount;
      } else if (b.cost.currency == 'accountGold') {
        if (progress.accountGold < b.cost.amount) {
          return '골드 부족';
        }
        progress.accountGold -= b.cost.amount;
      }
    }
    final rng = math.Random();
    final roll = rng.nextDouble() * 100;
    double acc = 0;
    String rarity = b.rates.first.rarity;
    for (final rate in b.rates) {
      acc += rate.percent;
      if (roll <= acc) {
        rarity = rate.rarity;
        break;
      }
    }

    final candidates = towerDefs.values.where((t) => t.rarity == rarity).toList();
    if (candidates.isEmpty) {
      return '획득 실패';
    }
    final tower = candidates[rng.nextInt(candidates.length)];
    final p = progress.towers[tower.id] ?? TowerProgress(towerId: tower.id, unlocked: false);
    p.shards += 5;
    progress.towers[tower.id] = p;
    return '${tower.id} 조각 +5 ($rarity)';
  }

  Widget _infoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(value),
      ],
    );
  }
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('도움말')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          _HelpSection(
            title: '게임 목표',
            body: '코어 빌딩을 지키며 모든 웨이브를 막아내면 승리합니다.',
          ),
          _HelpSection(
            title: '타워 배치',
            body: '길이 아닌 빈 칸을 터치해 타워를 건설합니다. '
                '타워 선택 후 건설이 됩니다.',
          ),
          _HelpSection(
            title: '전투 강화',
            body: '전투 중 타워를 강화하거나 매각할 수 있습니다. '
                '모듈로 공격력/공격속도/사거리를 임시 강화할 수 있습니다.',
          ),
          _HelpSection(
            title: '영구 성장',
            body: '로비의 타워 관리/건물 관리에서 영구 레벨과 코어 성장을 진행합니다.',
          ),
          _HelpSection(
            title: '난이도',
            body: '로비에서 난이도를 선택하면 적 체력/속도/보상이 변합니다.',
          ),
        ],
      ),
    );
  }
}

class RankingScreen extends StatelessWidget {
  const RankingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('랭킹')),
      body: FutureBuilder<List<RankingEntry>>(
        future: RankingRepository().load(),
        builder: (context, snapshot) {
          final list = snapshot.data ?? const [];
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Local Top 20',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (list.isEmpty)
                const Text('기록 없음')
              else
                ...list.asMap().entries.map((e) {
                  final index = e.key + 1;
                  final item = e.value;
                  return _rankRow(_RankEntry(rank: index, name: item.name, score: item.score));
                }).toList(),
            ],
          );
        },
      ),
    );
  }

  Widget _rankRow(_RankEntry entry) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('#${entry.rank}  ${entry.name}'),
            Text('${entry.score}'),
          ],
        ),
      ),
    );
  }
}

class DebugRankingSeedScreen extends StatelessWidget {
  const DebugRankingSeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('랭킹 디버그')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _PanelButton(
            label: '샘플 랭킹 추가',
            onPressed: () async {
              final repo = RankingRepository();
              await repo.addScore('NEON_AEGIS', 182340);
              await repo.addScore('CYBER_FALCON', 171220);
              await repo.addScore('GRID_HUNTER', 160880);
              await repo.addScore('ION_BLADE', 149300);
              await repo.addScore('NOVA_CORE', 141050);
            },
          ),
        ],
      ),
    );
  }
}

class _RankEntry {
  final int rank;
  final String name;
  final int score;

  const _RankEntry({required this.rank, required this.name, required this.score});
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool musicOn = true;
  bool sfxOn = true;
  bool showDamage = true;
  final SettingsRepository repo = SettingsRepository();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await repo.load();
    if (!mounted) return;
    setState(() {
      musicOn = data.musicOn;
      sfxOn = data.sfxOn;
      showDamage = data.showDamage;
    });
  }

  Future<void> _save() async {
    await repo.save(SettingsData(
      musicOn: musicOn,
      sfxOn: sfxOn,
      showDamage: showDamage,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('설정')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text('배경음악'),
            value: musicOn,
            onChanged: (v) async {
              setState(() => musicOn = v);
              await _save();
            },
          ),
          SwitchListTile(
            title: const Text('효과음'),
            value: sfxOn,
            onChanged: (v) async {
              setState(() => sfxOn = v);
              await _save();
            },
          ),
          SwitchListTile(
            title: const Text('데미지 표시'),
            value: showDamage,
            onChanged: (v) async {
              setState(() => showDamage = v);
              await _save();
            },
          ),
          const SizedBox(height: 12),
          _PanelButton(
            label: '랭킹 샘플 생성(테스트)',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DebugRankingSeedScreen()),
              );
            },
          ),
          const SizedBox(height: 12),
          _PanelButton(
            label: '로비로 돌아가기',
            onPressed: () => Navigator.of(context).pop(),
          ),
        ],
      ),
    );
  }
}

class _HelpSection extends StatelessWidget {
  final String title;
  final String body;

  const _HelpSection({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(body),
          ],
        ),
      ),
    );
  }
}

class BuildingManagementScreen extends StatefulWidget {
  final AccountProgress progress;

  const BuildingManagementScreen({super.key, required this.progress});

  @override
  State<BuildingManagementScreen> createState() => _BuildingManagementScreenState();
}

class _BuildingManagementScreenState extends State<BuildingManagementScreen> {
  late AccountProgress progress;
  final AccountProgressRepository progressRepo = AccountProgressRepository();

  @override
  void initState() {
    super.initState();
    progress = widget.progress;
  }

  @override
  Widget build(BuildContext context) {
    final core = progress.core;
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await progressRepo.save(progress);
          Navigator.of(context).pop(progress);
        }
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('건물 관리')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _infoRow('코어 레벨', '${core.level}'),
            _infoRow('HP', '${core.hp} (Lv${core.hpLevel})'),
            _infoRow('실드', '${core.shield} (Lv${core.shieldLevel})'),
            _infoRow('방어율', '${(core.defenseRate * 100).toStringAsFixed(0)}% (Lv${core.defenseLevel})'),
            const SizedBox(height: 16),
            _PanelButton(
              label: 'HP 강화 (비용 60)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 60) return;
                  progress.accountGold -= 60;
                  core.hpLevel += 1;
                  core.level += 1;
                  core.hp = (core.hp * 1.08).round();
                });
              },
            ),
            const SizedBox(height: 8),
            _PanelButton(
              label: '실드 강화 (비용 50)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 50) return;
                  progress.accountGold -= 50;
                  core.shieldLevel += 1;
                  core.level += 1;
                  core.shield = (core.shield * 1.06).round();
                });
              },
            ),
            const SizedBox(height: 8),
            _PanelButton(
              label: '방어율 강화 (비용 70)',
              onPressed: () {
                setState(() {
                  if (progress.accountGold < 70) return;
                  progress.accountGold -= 70;
                  core.defenseLevel += 1;
                  core.level += 1;
                  core.defenseRate = (core.defenseRate + 0.01).clamp(0, 0.9);
                });
              },
            ),
            const SizedBox(height: 12),
            _PanelButton(
              label: '로비로 돌아가기',
              onPressed: () async {
                await progressRepo.save(progress);
                Navigator.of(context).pop(progress);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(value),
      ],
    );
  }
}

class TowerManagementScreen extends StatefulWidget {
  final AccountProgress progress;

  const TowerManagementScreen({super.key, required this.progress});

  @override
  State<TowerManagementScreen> createState() => _TowerManagementScreenState();
}

class _TowerManagementScreenState extends State<TowerManagementScreen> {
  late AccountProgress progress;
  final DefinitionRepository repo = DefinitionRepository();
  final Map<String, TowerDef> towerDefs = {};
  final AccountProgressRepository progressRepo = AccountProgressRepository();

  @override
  void initState() {
    super.initState();
    progress = widget.progress;
    _loadDefs();
  }

  Future<void> _loadDefs() async {
    final defs = <String, TowerDef>{};
    for (final id in kAllTowerIds) {
      defs[id] = await repo.loadTower(id);
    }
    if (!mounted) return;
    setState(() => towerDefs.addAll(defs));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (!didPop) {
          await progressRepo.save(progress);
          Navigator.of(context).pop(progress);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('타워 관리'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _infoRow('보유 골드', '${progress.accountGold}'),
            const SizedBox(height: 12),
            ...towerDefs.values.map((def) => _towerCard(def)).toList(),
            const SizedBox(height: 16),
          _PanelButton(
            label: '로비로 돌아가기',
            onPressed: () async {
              await progressRepo.save(progress);
              Navigator.of(context).pop(progress);
            },
          ),
          ],
        ),
      ),
    );
  }

  Widget _towerCard(TowerDef def) {
    final p = progress.towers[def.id] ?? TowerProgress(towerId: def.id, unlocked: false);
    final maxLevel = 10;
    final unlockCost = def.unlockShards;
    final levelUpCost = _levelUpShards(def, p.level);
    final canUnlock = !p.unlocked && p.shards >= unlockCost;
    final canLevelUp = p.unlocked && p.level < maxLevel && p.shards >= levelUpCost;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(def.id, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('레벨: ${p.level} / $maxLevel'),
            Text('보유 조각: ${p.shards}'),
            Text('해금 상태: ${p.unlocked ? '해금됨' : '잠김'}'),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _PanelButton(
                    label: p.unlocked ? '레벨업 ($levelUpCost)' : '해금 ($unlockCost)',
                    onPressed: () {
                      setState(() {
                        if (!p.unlocked && canUnlock) {
                          p.shards -= unlockCost;
                          p.unlocked = true;
                        } else if (p.unlocked && canLevelUp) {
                          p.shards -= levelUpCost;
                          p.level += 1;
                        }
                        progress.towers[def.id] = p;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _PanelButton(
                    label: '조각 +5',
                    onPressed: () {
                      setState(() {
                        p.shards += 5;
                        progress.towers[def.id] = p;
                      });
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  int _levelUpShards(TowerDef def, int level) {
    final multiplier = math.pow(def.levelUpShardsMultiplier, (level - 1)).toDouble();
    return (def.levelUpShardsBase * multiplier).round();
  }

  Widget _infoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(value),
      ],
    );
  }
}

enum EnemyType { grunt, sprinter, tank }

enum EnemyAnim { right, up, hit, die }

String _enemySpritePath(EnemyType type) {
  return switch (type) {
    EnemyType.grunt => 'enemies/Runner Drone.png',
    EnemyType.sprinter => 'enemies/Riot Bot.png',
    EnemyType.tank => 'enemies/Shield Carrier.png',
  };
}

String? _towerSpritePath(String towerId) {
  return switch (towerId) {
    'cannon_basic' => 'towers/Pulse Turret.png',
    'rapid_basic' => 'towers/Railguard Battery.png',
    'shotgun_basic' => 'towers/Scatter Blaster.png',
    'frost_basic' => 'towers/Frost Relay.png',
    'drone_basic' => 'towers/Drone Dock.png',
    'chain_basic' => 'towers/Tesla Arc Node.png',
    'missile_basic' => 'towers/Missile Matrix.png',
    'support_basic' => 'towers/Nano Support Beacon.png',
    'laser_basic' => 'towers/Prism Laser Array.png',
    'sniper_basic' => 'towers/Holo Sniper Spire.png',
    'gravity_basic' => 'towers/Gravity Well Emitter.png',
    'infection_basic' => 'towers/Virus Injector.png',
    'chrono_basic' => 'towers/Chrono Distortion Core.png',
    'singularity_basic' => 'towers/Singularity Cannon.png',
    'mortar_basic' => 'towers/Aegis AI Citadel.png',
    _ => null,
  };
}


Color _rarityColor(String? rarity) {
  return switch (rarity) {
    'common' => const Color(0xFF6C63FF),
    'rare' => const Color(0xFF00D2A5),
    'unique' => const Color(0xFFB85BFF),
    'legendary' => const Color(0xFFFFC857),
    _ => const Color(0xFF7A7A7A),
  };
}

String _towerLabelFromId(String id) {
  final base = id.split('_').first;
  if (base.length <= 2) return base.toUpperCase();
  return base.substring(0, 2).toUpperCase();
}

String _towerDisplayName(String id) {
  return switch (id) {
    'cannon_basic' => 'Pulse Turret',
    'rapid_basic' => 'Railguard Battery',
    'shotgun_basic' => 'Scatter Blaster',
    'frost_basic' => 'Frost Relay',
    'drone_basic' => 'Drone Dock',
    'chain_basic' => 'Tesla Arc Node',
    'missile_basic' => 'Missile Matrix',
    'support_basic' => 'Nano Support Beacon',
    'laser_basic' => 'Prism Laser Array',
    'sniper_basic' => 'Holo Sniper Spire',
    'gravity_basic' => 'Gravity Well Emitter',
    'infection_basic' => 'Virus Injector',
    'chrono_basic' => 'Chrono Distortion Core',
    'singularity_basic' => 'Singularity Cannon',
    'mortar_basic' => 'Aegis AI Citadel',
    _ => id,
  };
}

enum TargetingRule { nearest, farthestProgress, highestHp, lowestHp }

enum TacticalModule { none, focus, overclock, range }

const List<String> kAllTowerIds = [
  'cannon_basic',
  'rapid_basic',
  'shotgun_basic',
  'frost_basic',
  'drone_basic',
  'chain_basic',
  'missile_basic',
  'support_basic',
  'laser_basic',
  'sniper_basic',
  'gravity_basic',
  'infection_basic',
  'chrono_basic',
  'singularity_basic',
  'mortar_basic',
];

class TowerDefenseGame extends FlameGame with TapCallbacks {
  final VoidCallback? onExitToLobby;
  final String difficultyId;
  final AccountProgress accountProgress;

  TowerDefenseGame({
    this.onExitToLobby,
    required this.difficultyId,
    required this.accountProgress,
  });
  late int gridWidth;
  late int gridHeight;

  double tileSize = 32;
  Vector2 mapOrigin = Vector2.zero();

  late final MapComponent map;
  Sprite? mapBackground;
  late final List<GridPoint> path;
  late final Map<GridPoint, Tower> towers;
  late final List<Enemy> enemies;
  late final SpawnController spawner;
  late final Set<GridPoint> buildCells;
  late final List<WaveDef> waves;
  int currentWaveIndex = 0;
  late final CoreBuilding core;
  late final Map<String, EnemyDef> enemyDefs;
  late final BattleHud hud;
  late final StageDef stageDef;
  late final DifficultyDef difficultyDef;
  late final ModeDef modeDef;
  late final Map<String, TowerDef> towerDefs;
  late final BalanceConfig balanceConfig;

  double coreHp = 100;
  double coreMaxHp = 100;
  double coreShield = 0;
  double coreMaxShield = 0;
  double coreDefenseRate = 0;
  bool defeated = false;
  ResultOverlay? resultOverlay;
  int battleGold = 200;
  int accountGold = 0;
  bool waveClearRewarded = false;
  bool victory = false;
  TargetingRule currentRule = TargetingRule.nearest;
  double timeScale = 1.0;
  bool debugOpen = false;
  bool debugInfiniteGold = false;
  bool debugShowDps = false;
  bool debugInfiniteWaves = false;
  bool debugInfiniteCore = false;

  TowerPicker? picker;
  TowerActionPanel? towerPanel;
  bool _ready = false;

  Future<Sprite?> _loadMapBackground() async {
    try {
      return await loadSprite('maps/map_01.png');
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    final repo = DefinitionRepository();
    stageDef = await repo.loadStage('story_01');
    modeDef = await repo.loadMode(stageDef.modeId);
    difficultyDef = await repo.loadDifficulty(difficultyId);
    balanceConfig = await BalanceRepository().load();
    final mapDef = await repo.loadMap(stageDef.mapId);
    mapBackground = await _loadMapBackground();
    waves = [];
    for (final id in stageDef.waveIds) {
      waves.add(await repo.loadWave(id));
    }
    enemyDefs = {
      'grunt_basic': await repo.loadEnemy('grunt_basic'),
      'sprinter_basic': await repo.loadEnemy('sprinter_basic'),
      'tank_basic': await repo.loadEnemy('tank_basic'),
    };
    final defs = <String, TowerDef>{};
    for (final id in kAllTowerIds) {
      defs[id] = await repo.loadTower(id);
    }
    towerDefs = defs;
    gridWidth = mapDef.gridWidth;
    gridHeight = mapDef.gridHeight;

    path = mapDef.path.map((p) => GridPoint(p.x, p.y)).toList();
    buildCells = _buildCellsFromDef(mapDef);
    towers = {};
    enemies = [];

    final coreProgress = accountProgress.core;
    coreMaxHp = coreProgress.hp.toDouble();
    coreHp = coreMaxHp;
    coreMaxShield = coreProgress.shield.toDouble();
    coreShield = coreMaxShield;
    coreDefenseRate = coreProgress.defenseRate;

    map = MapComponent(gameRef: this, path: path, background: mapBackground);
    add(map);

    // Start/end markers disabled (path guide only).
    core = CoreBuilding(gameRef: this, positionCell: path.last);
    core.setStats(coreHp, coreMaxHp, coreShield, coreMaxShield);
    add(core);
    hud = BattleHud(gameRef: this);
    add(hud);

    spawner = SpawnController(game: this, waveDef: waves[currentWaveIndex]);
    add(spawner);

    _ready = true;
    if (size.x > 0 && size.y > 0) {
      onGameResize(size);
    }
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (!_ready) return;

    final tileX = (size.x / gridWidth).floorToDouble();
    final tileY = (size.y / gridHeight).floorToDouble();
    final raw = math.min(tileX, tileY) * 0.95;
    tileSize = raw.floorToDouble().clamp(16.0, 80.0);

    final mapWidth = gridWidth * tileSize;
    final mapHeight = gridHeight * tileSize;
    mapOrigin = Vector2(
      (size.x - mapWidth) / 2,
      (size.y - mapHeight) / 2,
    );

    if (!_ready) return;

    map.position = mapOrigin;
    map.size = Vector2(mapWidth, mapHeight);
    hud.onGameResize(size);

    for (final tower in towers.values) {
      tower.updateWorldPosition();
    }

    for (final enemy in enemies) {
      enemy.updateWorldPosition();
    }

    picker?.updateLayout();
    towerPanel?.updateLayout();
  }

  @override
  void update(double dt) {
    final scaledDt = dt * timeScale;
    super.update(scaledDt);
    if (debugInfiniteGold) {
      battleGold = 999999;
    }
    for (final tower in towers.values) {
      tower.updateTower(scaledDt, enemies);
    }

    enemies.removeWhere((enemy) => enemy.isRemoved);

    if (!waveClearRewarded && spawner.isFinished && enemies.isEmpty) {
      addBattleGoldScaled(waves[currentWaveIndex].waveClearReward);
      waveClearRewarded = true;
      _advanceWaveIfPossible();
    }
  }

  @override
  void onTapDown(TapDownEvent event) {
    super.onTapDown(event);
    if (defeated || victory) {
      if (resultOverlay?.hitTest(event.canvasPosition) ?? false) {
        onExitToLobby?.call();
      }
      return;
    }
    if (hud.hitRuleButton(event.canvasPosition)) {
      _cycleTargetRule();
      return;
    }
    if (hud.hitSpeedButton(event.canvasPosition)) {
      _toggleSpeed();
      return;
    }
    if (hud.hitDebugButton(event.canvasPosition)) {
      debugOpen = !debugOpen;
      debugInfiniteWaves = debugOpen;
      debugInfiniteCore = debugOpen;
      return;
    }
    if (debugOpen && hud.hitDebugPanel(event.canvasPosition, this)) {
      return;
    }
    final pos = event.canvasPosition;

    if (picker != null) {
      final selected = picker!.hitTest(pos);
      if (selected != null) {
        _buildTower(picker!.cell, selected);
      }
      _closePicker();
      return;
    }
    if (towerPanel != null) {
      final action = towerPanel!.hitTest(pos);
      if (action != null) {
        _handleTowerAction(towerPanel!.cell, action);
      }
      _closeTowerPanel();
      return;
    }

    final cell = _worldToGrid(pos);
    if (cell == null) return;
    if (towers.containsKey(cell)) {
      _openTowerPanel(cell);
      return;
    }
    if (!_isBuildable(cell)) return;

    _openPicker(cell);
  }

  void _openPicker(GridPoint cell) {
    _closePicker();
    _closeTowerPanel();
    picker = TowerPicker(gameRef: this, cell: cell);
    add(picker!);
  }

  void _closePicker() {
    picker?.removeFromParent();
    picker = null;
  }

  void _buildTower(GridPoint cell, String towerId) {
    final def = towerDefs[towerId];
    if (def == null) return;
    if (!_isTowerUnlocked(def.id)) return;
    final cost = def.buildCost;
    if (battleGold < cost) return;
    battleGold -= cost;
    final tower = Tower(gameRef: this, towerId: towerId, grid: cell, def: def);
    towers[cell] = tower;
    add(tower);
  }

  bool _isTowerUnlocked(String towerId) {
    if (debugOpen) return true;
    final progress = accountProgress.towers[towerId];
    return progress?.unlocked ?? false;
  }

  int _getTowerPermanentLevel(String towerId) {
    return accountProgress.towers[towerId]?.level ?? 1;
  }

  void _openTowerPanel(GridPoint cell) {
    _closePicker();
    _closeTowerPanel();
    towerPanel = TowerActionPanel(gameRef: this, cell: cell);
    add(towerPanel!);
  }

  void _closeTowerPanel() {
    towerPanel?.removeFromParent();
    towerPanel = null;
  }

  void _handleTowerAction(GridPoint cell, Object action) {
    final tower = towers[cell];
    if (tower == null) return;
    if (action == TowerAction.upgrade) {
      final cost = tower.nextUpgradeCost;
      if (battleGold >= cost) {
        battleGold -= cost;
        tower.upgrade();
      }
    } else if (action == TowerAction.sell) {
      final refund = tower.sellRefund;
      battleGold += refund;
      tower.removeFromParent();
      towers.remove(cell);
    } else if (action == TowerActionExtra.cycleModule) {
      tower.cycleModule();
    }
  }

  GridPoint? _worldToGrid(Vector2 pos) {
    final local = pos - mapOrigin;
    if (local.x < 0 || local.y < 0) return null;
    final x = (local.x / tileSize).floor();
    final y = (local.y / tileSize).floor();
    if (x < 0 || y < 0 || x >= gridWidth || y >= gridHeight) return null;
    return GridPoint(x, y);
  }

  bool _isBuildable(GridPoint cell) => buildCells.contains(cell);

  Set<GridPoint> _buildCellsFromDef(MapDef mapDef) {
    if (mapDef.buildCells.isNotEmpty) {
      return mapDef.buildCells.map((p) => GridPoint(p.x, p.y)).toSet();
    }
    final pathSet = path.toSet();
    final cells = <GridPoint>{};
    for (int y = 0; y < gridHeight; y++) {
      for (int x = 0; x < gridWidth; x++) {
        final cell = GridPoint(x, y);
        if (!pathSet.contains(cell)) {
          cells.add(cell);
        }
      }
    }
    return cells;
  }

  void spawnEnemy(EnemyType type, EnemyDef def) {
    final enemy = Enemy(
      gameRef: this,
      type: type,
      def: def,
      path: path,
      hpMultiplier: difficultyDef.hpMultiplier,
      speedMultiplier: difficultyDef.speedMultiplier,
      rewardMultiplier: difficultyDef.rewardMultiplier,
    );
    enemies.add(enemy);
    add(enemy);
  }

  void spawnEnemyById(String enemyId) {
    final def = enemyDefs[enemyId];
    if (def == null) return;
    final type = switch (enemyId) {
      'sprinter_basic' => EnemyType.sprinter,
      'tank_basic' => EnemyType.tank,
      _ => EnemyType.grunt,
    };
    spawnEnemy(type, def);
  }

  void damageCore(double amount) {
    if (debugInfiniteCore) {
      coreHp = coreMaxHp;
      coreShield = coreMaxShield;
      core.setStats(coreHp, coreMaxHp, coreShield, coreMaxShield);
      return;
    }
    final reduced = amount * (1.0 - coreDefenseRate).clamp(0.0, 1.0);
    var remaining = reduced;
    if (coreShield > 0) {
      final used = coreShield >= remaining ? remaining : coreShield;
      coreShield -= used;
      remaining -= used;
    }
    if (remaining > 0) {
      coreHp = (coreHp - remaining).clamp(0, coreMaxHp);
    }
    core.setStats(coreHp, coreMaxHp, coreShield, coreMaxShield);
    if (coreHp <= 0 && _isLoseCondition('coreDestroyed')) {
      _onDefeat();
    }
  }

  void _onDefeat() {
    if (defeated) return;
    defeated = true;
    for (final enemy in enemies) {
      enemy.removeFromParent();
    }
    enemies.clear();
    spawner.pauseSpawning();
    resultOverlay = ResultOverlay(
      gameRef: this,
      title: '패배',
      subtitle: '코어가 파괴되었습니다',
      onExit: onExitToLobby,
    );
    add(resultOverlay!);
  }

  void addBattleGold(int amount) {
    battleGold += amount;
  }

  void addBattleGoldScaled(int amount) {
    final scaled = (amount * difficultyDef.rewardMultiplier).round();
    battleGold += scaled;
  }

  void _cycleTargetRule() {
    final values = TargetingRule.values;
    final nextIndex = (currentRule.index + 1) % values.length;
    currentRule = values[nextIndex];
  }

  void _toggleSpeed() {
    timeScale = timeScale >= 1.5 ? 1.0 : 2.0;
  }

  void _setSpeed(double value) {
    timeScale = value;
  }

  void debugSpawn(String id) {
    spawnEnemyById(id);
  }

  void debugLevelUpTowers() {
    for (final tower in towers.values) {
      tower.upgrade();
    }
  }

  void _advanceWaveIfPossible() {
    if (currentWaveIndex >= waves.length - 1) {
      if (debugInfiniteWaves) {
        currentWaveIndex = 0;
        waveClearRewarded = false;
        spawner.resetWith(waves[currentWaveIndex]);
        return;
      }
      if (_isWinCondition('allWavesCleared')) {
        _onVictory();
      }
      return;
    }
    currentWaveIndex++;
    waveClearRewarded = false;
    spawner.resetWith(waves[currentWaveIndex]);
  }

  bool _isWinCondition(String key) => modeDef.winCondition == key;
  bool _isLoseCondition(String key) => modeDef.loseCondition == key;

  void _onVictory() {
    if (victory || defeated) return;
    victory = true;
    spawner.pauseSpawning();
    accountGold += stageDef.reward.accountGold;
    resultOverlay = ResultOverlay(
      gameRef: this,
      title: '승리',
      subtitle: '모든 웨이브를 막았습니다',
      onExit: onExitToLobby,
    );
    add(resultOverlay!);
  }
}

class TowerPicker extends PositionComponent {
  final TowerDefenseGame gameRef;
  final GridPoint cell;

  late List<_HudButtonData> buttons;

  TowerPicker({required this.gameRef, required this.cell}) {
    priority = 2000;
    buttons = [
      for (final id in kAllTowerIds)
        _HudButtonData(
          id,
          _towerLabelFromId(id),
          _towerDisplayName(id),
          _rarityColor(gameRef.towerDefs[id]?.rarity),
        ),
    ];
  }

  @override
  void onMount() {
    super.onMount();
    updateLayout();
  }

  void updateLayout() {
    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    final rows = (buttons.length / cols).ceil();
    size.setValues(
      buttonSize * cols + padding * (cols + 1),
      (buttonSize + labelHeight) * rows + padding * (rows + 1),
    );

    final cellPos = cell.toWorld(gameRef);
    final left = cellPos.x - size.x / 2;
    final top = cellPos.y - size.y - gameRef.tileSize * 0.3;

    final minX = gameRef.mapOrigin.x;
    final maxX = gameRef.mapOrigin.x + gameRef.gridWidth * gameRef.tileSize - size.x;
    final minY = gameRef.mapOrigin.y;
    final maxY = gameRef.mapOrigin.y + gameRef.gridHeight * gameRef.tileSize - size.y;

    position.setValues(
      left.clamp(minX, maxX),
      top.clamp(minY, maxY),
    );
  }

  String? hitTest(Vector2 worldPos) {
    final local = worldPos - position;
    if (local.x < 0 || local.y < 0 || local.x > size.x || local.y > size.y) {
      return null;
    }

    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    for (int i = 0; i < buttons.length; i++) {
      final row = i ~/ cols;
      final col = i % cols;
      final x = padding + col * (buttonSize + padding);
      final y = padding + row * (buttonSize + labelHeight + padding);
      final rect = Rect.fromLTWH(x, y, buttonSize, buttonSize);
      if (rect.contains(Offset(local.x, local.y))) {
        final def = gameRef.towerDefs[buttons[i].towerId];
        if (def == null) return null;
        final unlocked =
            gameRef.debugOpen || (gameRef.accountProgress.towers[def.id]?.unlocked ?? false);
        if (!unlocked) return null;
        return buttons[i].towerId;
      }
    }
    return null;
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xEE1B1B22);
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(10)), bgPaint);

    final buttonSize = gameRef.tileSize * 1.2;
    final padding = gameRef.tileSize * 0.25;
    final labelHeight = gameRef.tileSize * 0.35;
    const cols = 5;
    final labelPaint = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.bold,
      ),
    );
    final namePaint = TextPaint(
      style: const TextStyle(
        color: Color(0xFFB8C2D4),
        fontSize: 9,
      ),
    );

    for (int i = 0; i < buttons.length; i++) {
      final data = buttons[i];
      final row = i ~/ cols;
      final col = i % cols;
      final x = padding + col * (buttonSize + padding);
      final y = padding + row * (buttonSize + labelHeight + padding);
      final rect = Rect.fromLTWH(x, y, buttonSize, buttonSize);

      final paint = Paint()..color = data.color;
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), paint);
      labelPaint.render(
        canvas,
        data.label,
        Vector2(x + buttonSize / 2 - 6, y + buttonSize / 2 - 8),
      );
      namePaint.render(canvas, data.name, Vector2(x, y + buttonSize + 2));

      final def = gameRef.towerDefs[data.towerId];
      final locked = def == null
          ? true
          : !(gameRef.debugOpen ||
              (gameRef.accountProgress.towers[def.id]?.unlocked ?? false));
      if (locked) {
        final shade = Paint()..color = const Color(0xAA000000);
        canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), shade);
        final lockText = TextPaint(
          style: const TextStyle(
            color: Colors.white,
            fontSize: 10,
            fontWeight: FontWeight.bold,
          ),
        );
        lockText.render(canvas, 'LOCK', Vector2(x + 4, y + buttonSize / 2 - 6));
      }
    }
  }
}

enum TowerAction { upgrade, sell }
enum TowerActionExtra { cycleModule }

class TowerActionPanel extends PositionComponent {
  final TowerDefenseGame gameRef;
  final GridPoint cell;
  Rect? _upgradeRect;
  Rect? _sellRect;
  Rect? _moduleRect;

  TowerActionPanel({required this.gameRef, required this.cell}) {
    priority = 2000;
  }

  @override
  void onMount() {
    super.onMount();
    updateLayout();
  }

  void updateLayout() {
    final buttonW = gameRef.tileSize * 2.4;
    final buttonH = gameRef.tileSize * 0.7;
    final padding = gameRef.tileSize * 0.2;
    size = Vector2(buttonW + padding * 2, buttonH * 3 + padding * 4);

    final cellPos = cell.toWorld(gameRef);
    final left = cellPos.x - size.x / 2;
    final top = cellPos.y - size.y - gameRef.tileSize * 0.2;

    final minX = gameRef.mapOrigin.x;
    final maxX = gameRef.mapOrigin.x + gameRef.gridWidth * gameRef.tileSize - size.x;
    final minY = gameRef.mapOrigin.y;
    final maxY = gameRef.mapOrigin.y + gameRef.gridHeight * gameRef.tileSize - size.y;

    position.setValues(
      left.clamp(minX, maxX),
      top.clamp(minY, maxY),
    );

    _upgradeRect = Rect.fromLTWH(
      padding,
      padding,
      buttonW,
      buttonH,
    );
    _sellRect = Rect.fromLTWH(
      padding,
      padding * 2 + buttonH,
      buttonW,
      buttonH,
    );
    _moduleRect = Rect.fromLTWH(
      padding,
      padding * 3 + buttonH * 2,
      buttonW,
      buttonH,
    );
  }

  Object? hitTest(Vector2 worldPos) {
    final local = worldPos - position;
    if (local.x < 0 || local.y < 0 || local.x > size.x || local.y > size.y) {
      return null;
    }
    if (_upgradeRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerAction.upgrade;
    }
    if (_sellRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerAction.sell;
    }
    if (_moduleRect?.contains(Offset(local.x, local.y)) ?? false) {
      return TowerActionExtra.cycleModule;
    }
    return null;
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xEE1B1B22);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, size.x, size.y), const Radius.circular(8)),
      bgPaint,
    );

    final tower = gameRef.towers[cell];
    final level = tower?.state.level ?? 1;
    final upgradeCost = tower?.nextUpgradeCost ?? 0;
    final refund = tower?.sellRefund ?? 0;
    final module = tower?.state.module ?? TacticalModule.none;

    final label = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),
    );

    _drawButton(canvas, _upgradeRect, '강화 (Lv$level) - $upgradeCost', const Color(0xFF2B7FFF), label);
    _drawButton(canvas, _sellRect, '매각 +$refund', const Color(0xFF9E2B2B), label);
    _drawButton(
      canvas,
      _moduleRect,
      '모듈: ${_moduleLabel(module)}',
      const Color(0xFF4A5568),
      label,
    );
  }

  void _drawButton(Canvas canvas, Rect? rect, String text, Color color, TextPaint label) {
    if (rect == null) return;
    final paint = Paint()..color = color;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), paint);
    label.render(canvas, text, Vector2(rect.left + 8, rect.top + 6));
  }

  String _moduleLabel(TacticalModule module) {
    return switch (module) {
      TacticalModule.none => '없음',
      TacticalModule.focus => '집중 사격',
      TacticalModule.overclock => '오버클럭',
      TacticalModule.range => '사거리 강화',
    };
  }
}

class GridPoint {
  final int x;
  final int y;

  const GridPoint(this.x, this.y);

  Vector2 toWorld(TowerDefenseGame game) =>
      game.mapOrigin + Vector2((x + 0.5) * game.tileSize, (y + 0.5) * game.tileSize);

  @override
  bool operator ==(Object other) => other is GridPoint && other.x == x && other.y == y;

  @override
  int get hashCode => Object.hash(x, y);
}

class MapComponent extends PositionComponent {
  final TowerDefenseGame gameRef;
  final List<GridPoint> path;
  final Sprite? background;
  final bool showPathOverlay;
  final bool showBuildOverlay;

  MapComponent({
    required this.gameRef,
    required this.path,
    this.background,
    this.showPathOverlay = true,
    this.showBuildOverlay = true,
  });

  @override
  void render(Canvas canvas) {
    final tile = gameRef.tileSize;
    final width = gameRef.gridWidth;
    final height = gameRef.gridHeight;

    if (background != null) {
      background!.render(
        canvas,
        position: Vector2.zero(),
        size: Vector2(width * tile, height * tile),
      );
    }

    if (background == null) {
      final bgPaint = Paint()..color = const Color(0xFF1A1D24);
      canvas.drawRect(Rect.fromLTWH(0, 0, width * tile, height * tile), bgPaint);

      final gridPaint = Paint()
        ..color = const Color(0xFF2A2F3A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1;

      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          canvas.drawRect(Rect.fromLTWH(x * tile, y * tile, tile, tile), gridPaint);
        }
      }
    }

    if (showPathOverlay) {
      final pathPaint = Paint()..color = const Color(0x77394253);
      for (final cell in path) {
        canvas.drawRect(Rect.fromLTWH(cell.x * tile, cell.y * tile, tile, tile), pathPaint);
      }
    }

    if (showBuildOverlay) {
      final buildPaint = Paint()
        ..color = const Color(0x66FFFFFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2;
      for (final cell in gameRef.buildCells) {
        canvas.drawRect(Rect.fromLTWH(cell.x * tile, cell.y * tile, tile, tile), buildPaint);
      }
    }
  }
}

class StartEndMarkers extends PositionComponent {
  final TowerDefenseGame gameRef;
  final List<GridPoint> path;

  StartEndMarkers({required this.gameRef, required this.path});

  @override
  void render(Canvas canvas) {
    final tile = gameRef.tileSize;
    final start = path.first;
    final end = path.last;

    final startPaint = Paint()..color = const Color(0xFF00BFA5);
    final endPaint = Paint()..color = const Color(0xFFFF5252);

    canvas.drawRect(Rect.fromLTWH(start.x * tile, start.y * tile, tile, tile), startPaint);
    canvas.drawRect(Rect.fromLTWH(end.x * tile, end.y * tile, tile, tile), endPaint);
  }
}

class CoreBuilding extends PositionComponent {
  final TowerDefenseGame gameRef;
  final GridPoint positionCell;

  double hp = 100;
  double maxHp = 100;
  double shield = 0;
  double maxShield = 0;

  CoreBuilding({required this.gameRef, required this.positionCell}) {
    size = Vector2(24, 24);
    anchor = Anchor.center;
    priority = 50;
  }

  void setStats(double currentHp, double totalHp, double currentShield, double totalShield) {
    hp = currentHp;
    maxHp = totalHp;
    shield = currentShield;
    maxShield = totalShield;
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    final tile = gameRef.tileSize;
    this.size = Vector2(tile * 0.7, tile * 0.7);
    position = positionCell.toWorld(gameRef);
  }

  @override
  void render(Canvas canvas) {
    final corePaint = Paint()..color = const Color(0xFF2B7FFF);
    final ringPaint = Paint()
      ..color = const Color(0xFF0B1A36)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawCircle(Offset.zero, size.x * 0.5, corePaint);
    canvas.drawCircle(Offset.zero, size.x * 0.5 + 2, ringPaint);

    final hpWidth = size.x;
    final hpHeight = 4.0;
    final ratio = maxHp <= 0 ? 0.0 : (hp / maxHp).clamp(0.0, 1.0);
    final shieldRatio = maxShield <= 0 ? 0.0 : (shield / maxShield).clamp(0.0, 1.0);

    final bgPaint = Paint()..color = const Color(0xFF1E1E1E);
    final fgPaint = Paint()..color = const Color(0xFF33B36A);

    canvas.drawRect(Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 10, hpWidth, hpHeight), bgPaint);
    canvas.drawRect(
      Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 10, hpWidth * ratio, hpHeight),
      fgPaint,
    );

    if (maxShield > 0) {
      final shieldBg = Paint()..color = const Color(0xFF1B2B3A);
      final shieldFg = Paint()..color = const Color(0xFF4FC3F7);
      canvas.drawRect(
        Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 16, hpWidth, hpHeight),
        shieldBg,
      );
      canvas.drawRect(
        Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 16, hpWidth * shieldRatio, hpHeight),
        shieldFg,
      );
    }
  }
}

class Enemy extends SpriteAnimationGroupComponent<EnemyAnim> {
  final TowerDefenseGame gameRef;
  final EnemyType type;
  final EnemyDef def;
  final List<GridPoint> path;
  final double hpMultiplier;
  final double speedMultiplier;
  final double rewardMultiplier;

  late double speed;
  late double hp;
  late double maxHp;

  int pathIndex = 0;
  bool reachedGoal = false;
  bool atCore = false;
  double attackTimer = 0;
  final double attackInterval = 1.0;
  final double attackDamage = 5;
  double progress = 0;

  double hitTimer = 0;
  bool isDying = false;
  double deathTimer = 0;
  EnemyAnim lastMoveAnim = EnemyAnim.right;
  Vector2 lastScale = Vector2(1, 1);
  double attackPulse = 0;
  double attackNudge = 0;
  Vector2 attackDir = Vector2.zero();

  static const double _frameTime = 0.12;
  static const int _frames = 5;
  static const double _hitDuration = _frames * _frameTime;
  static const double _dieDuration = _frames * _frameTime;
  static const double _attackPulseDuration = 0.18;
  static const double _attackPulseScale = 0.12;
  static const double _attackNudgeDuration = 0.12;
  static const double _attackNudgeScale = 0.18;

  Enemy({
    required this.gameRef,
    required this.type,
    required this.def,
    required this.path,
    required this.hpMultiplier,
    required this.speedMultiplier,
    required this.rewardMultiplier,
  }) : super() {
    final tile = gameRef.tileSize;
    size = Vector2(tile * 1.05, tile * 1.05);
    anchor = Anchor.center;

    speed = def.speed * speedMultiplier;
    maxHp = def.hp * hpMultiplier;
    hp = maxHp;
    position = path.first.toWorld(gameRef);
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final image = await gameRef.images.load(_enemySpritePath(type));
    final sheet = SpriteSheet.fromColumnsAndRows(
      image: image,
      columns: 5,
      rows: 4,
    );

    animations = {
      EnemyAnim.right: sheet.createAnimation(
        row: 0,
        stepTime: _frameTime,
        from: 0,
        to: _frames,
      ),
      EnemyAnim.up: sheet.createAnimation(
        row: 1,
        stepTime: _frameTime,
        from: 0,
        to: _frames,
      ),
      EnemyAnim.hit: sheet.createAnimation(
        row: 2,
        stepTime: _frameTime,
        from: 0,
        to: _frames,
        loop: false,
      ),
      EnemyAnim.die: sheet.createAnimation(
        row: 3,
        stepTime: _frameTime,
        from: 0,
        to: _frames,
        loop: false,
      ),
    };
    current = EnemyAnim.right;
    scale = Vector2(1, 1);
  }

  void updateWorldPosition() {
    position = path[pathIndex].toWorld(gameRef);
  }

  void _applyDirection(Vector2 dir) {
    final dx = dir.x;
    final dy = dir.y;
    if (dx.abs() >= dy.abs()) {
      if (dx >= 0) {
        current = EnemyAnim.right;
        scale = Vector2(1, 1);
      } else {
        current = EnemyAnim.right;
        scale = Vector2(-1, 1);
      }
    } else {
      if (dy >= 0) {
        current = EnemyAnim.up;
        scale = Vector2(1, -1);
      } else {
        current = EnemyAnim.up;
        scale = Vector2(1, 1);
      }
    }
    lastMoveAnim = current ?? EnemyAnim.right;
    lastScale = scale.clone();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (attackPulse > 0) {
      attackPulse = (attackPulse - dt).clamp(0.0, _attackPulseDuration);
    }
    if (attackNudge > 0) {
      attackNudge = (attackNudge - dt).clamp(0.0, _attackNudgeDuration);
    }
    if (isDying) {
      deathTimer += dt;
      if (deathTimer >= _dieDuration) {
        removeFromParent();
      }
      return;
    }
    if (hitTimer > 0) {
      hitTimer -= dt;
      if (hitTimer <= 0) {
        current = lastMoveAnim;
        scale = lastScale.clone();
      }
    }
    if (atCore) {
      attackTimer += dt;
      if (attackTimer >= attackInterval) {
        attackTimer = 0;
        gameRef.damageCore(attackDamage);
        attackPulse = _attackPulseDuration;
        final dir = (gameRef.core.position - position);
        attackDir = dir.length > 0 ? dir.normalized() : Vector2(0, 1);
        attackNudge = _attackNudgeDuration;
      }
      _applyAttackPulse();
      return;
    }

    if (pathIndex >= path.length - 1) {
      atCore = true;
      position = path.last.toWorld(gameRef);
      progress = 1;
      return;
    }

    final target = path[pathIndex + 1].toWorld(gameRef);
    final toTarget = target - position;
    final distance = toTarget.length;

    if (hitTimer <= 0) {
      _applyDirection(toTarget);
    }
    _applyAttackPulse();

    if (distance < speed * dt) {
      position = target;
      pathIndex++;
    } else {
      position += toTarget.normalized() * speed * dt;
    }

    final denom = (path.length - 1);
    if (denom > 0) {
      progress = (pathIndex / denom).clamp(0.0, 1.0);
    }
  }

  void takeDamage(double dmg) {
    hp -= dmg;
    if (hp <= 0) {
      gameRef.addBattleGoldScaled(def.rewardBattleGold);
      if (!isDying) {
        isDying = true;
        deathTimer = 0;
        current = EnemyAnim.die;
      }
      return;
    }
    if (!isDying) {
      hitTimer = _hitDuration;
      current = EnemyAnim.hit;
    }
  }

  @override
  void render(Canvas canvas) {
    if (attackNudge > 0) {
      final t = (attackNudge / _attackNudgeDuration).clamp(0.0, 1.0);
      final offset = attackDir * (size.x * _attackNudgeScale * t);
      canvas.save();
      canvas.translate(offset.x, offset.y);
      super.render(canvas);
      canvas.restore();
    } else {
      super.render(canvas);
    }

    if (attackPulse > 0) {
      final t = (attackPulse / _attackPulseDuration).clamp(0.0, 1.0);
      final glow = Paint()..color = Color.lerp(const Color(0x00FF3B30), const Color(0x88FF3B30), t)!;
      canvas.drawCircle(Offset.zero, size.x * 0.6, glow);
    }

    final hpWidth = size.x;
    final hpHeight = 4.0;
    final hpRatio = maxHp <= 0 ? 0.0 : (hp / maxHp).clamp(0.0, 1.0);

    final bgPaint = Paint()..color = const Color(0xFF2B2B2B);
    final fgPaint = Paint()..color = const Color(0xFF8BC34A);

    canvas.drawRect(Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 6, hpWidth, hpHeight), bgPaint);
    canvas.drawRect(
      Rect.fromLTWH(-hpWidth / 2, -size.y / 2 - 6, hpWidth * hpRatio, hpHeight),
      fgPaint,
    );
  }

  void _applyAttackPulse() {
    if (attackPulse <= 0) {
      scale = lastScale.clone();
      return;
    }
    final t = (attackPulse / _attackPulseDuration).clamp(0.0, 1.0);
    final s = 1.0 + _attackPulseScale * t;
    scale = Vector2(lastScale.x * s, lastScale.y * s);
  }
}

class Projectile extends PositionComponent {
  final TowerDefenseGame gameRef;
  final Vector2 targetPos;
  final Enemy target;
  final double damage;
  final double speed;
  final double sizePx;

  late final Vector2 direction;

  Projectile({
    required this.gameRef,
    required Vector2 origin,
    required this.targetPos,
    required this.target,
    required this.damage,
    required this.speed,
    required this.sizePx,
  }) {
    position = origin;
    size = Vector2(sizePx, sizePx);
    anchor = Anchor.center;
    direction = (targetPos - origin).normalized();
  }

  @override
  void update(double dt) {
    super.update(dt);
    final step = speed * dt;
    final toTarget = targetPos - position;
    if (toTarget.length <= step) {
      position = targetPos;
      _impact();
      return;
    }
    position += direction * step;
  }

  void _impact() {
    if (!target.isRemoved) {
      final hitRadius = math.max(6, target.size.x * 0.4);
      if (target.position.distanceTo(position) <= hitRadius) {
        target.takeDamage(damage);
      }
    }
    removeFromParent();
  }

  @override
  void render(Canvas canvas) {
    final paint = Paint()..color = const Color(0xFFFFD54F);
    canvas.drawCircle(Offset.zero, size.x * 0.5, paint);
  }
}

class HitscanEffect extends PositionComponent {
  final Vector2 start;
  final Vector2 end;
  double life = 0.08;

  HitscanEffect({required this.start, required this.end}) {
    priority = 900;
  }

  @override
  void update(double dt) {
    super.update(dt);
    life -= dt;
    if (life <= 0) {
      removeFromParent();
    }
  }

  @override
  void render(Canvas canvas) {
    final paint = Paint()
      ..color = const Color(0xFFFF8F00)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(start.x, start.y), Offset(end.x, end.y), paint);
  }
}

class ResultOverlay extends PositionComponent {
  final TowerDefenseGame gameRef;
  final VoidCallback? onExit;
  final String title;
  final String subtitle;
  Rect? _buttonRect;

  ResultOverlay({
    required this.gameRef,
    required this.title,
    required this.subtitle,
    this.onExit,
  }) {
    priority = 5000;
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    this.size = size;
    position = Vector2.zero();
    final center = size / 2;
    _buttonRect = Rect.fromCenter(
      center: Offset(center.x, center.y + 10),
      width: 180,
      height: 36,
    );
  }

  @override
  void render(Canvas canvas) {
    final bgPaint = Paint()..color = const Color(0xCC000000);
    canvas.drawRect(size.toRect(), bgPaint);

    final panelRect = Rect.fromCenter(
      center: Offset(size.x / 2, size.y / 2 - 10),
      width: 260,
      height: 160,
    );
    final panelPaint = Paint()..color = const Color(0xFF121622);
    final panelBorder = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawRRect(RRect.fromRectAndRadius(panelRect, const Radius.circular(10)), panelPaint);
    canvas.drawRRect(RRect.fromRectAndRadius(panelRect, const Radius.circular(10)), panelBorder);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 28,
        fontWeight: FontWeight.bold,
      ),
    );
    final sub = TextPaint(
      style: const TextStyle(
        color: Color(0xFFB5B5C0),
        fontSize: 14,
      ),
    );

    final center = size / 2;
    text.render(canvas, title, center - Vector2(18, 70));
    sub.render(canvas, subtitle, center - Vector2(80, -50));

    final stat = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 13,
      ),
    );
    stat.render(
      canvas,
      'Battle Gold: ${gameRef.battleGold}',
      center - Vector2(80, -20),
    );
    stat.render(
      canvas,
      'Account Gold: ${gameRef.accountGold}',
      center - Vector2(80, 0),
    );

    _renderButton(canvas, center + Vector2(0, 10), '로비로 돌아가기');
  }

  void _renderButton(Canvas canvas, Vector2 center, String label) {
    final w = 180.0;
    final h = 36.0;
    final rect = Rect.fromCenter(center: Offset(center.x, center.y), width: w, height: h);
    final paint = Paint()..color = const Color(0xFF1B1F2A);
    final border = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), paint);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), border);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.bold,
      ),
    );
    text.render(canvas, label, Vector2(center.x - 60, center.y - 8));
  }

  bool hitTest(Vector2 worldPos) {
    if (_buttonRect == null) return false;
    return _buttonRect!.contains(Offset(worldPos.x, worldPos.y));
  }
}

class BattleHud extends PositionComponent {
  final TowerDefenseGame gameRef;
  Rect? _ruleButtonRect;
  Rect? _speedButtonRect;
  Rect? _debugButtonRect;
  Rect? _debugPanelRect;

  BattleHud({required this.gameRef}) {
    priority = 1200;
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    this.size = size;
    position = Vector2.zero();
    _ruleButtonRect = Rect.fromLTWH(8, 32, 140, 22);
    _speedButtonRect = Rect.fromLTWH(160, 32, 70, 22);
    _debugButtonRect = Rect.fromLTWH(size.x - 34, 32, 26, 22);
    _debugPanelRect = Rect.fromLTWH(size.x - 190, 60, 180, 180);
  }

  @override
  void render(Canvas canvas) {
    final barHeight = 28.0;
    final bg = Paint()..color = const Color(0xAA0B0B12);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.x, barHeight), bg);

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),
    );
    text.render(canvas, 'Battle Gold: ${gameRef.battleGold}', Vector2(8, 6));
    text.render(
      canvas,
      'Wave ${gameRef.currentWaveIndex + 1} / ${gameRef.waves.length}',
      Vector2(140, 6),
    );
    text.render(
      canvas,
      'Account Gold: ${gameRef.accountGold}',
      Vector2(260, 6),
    );
    text.render(
      canvas,
      '적: ${gameRef.enemies.length}',
      Vector2(8, 18),
    );
    text.render(
      canvas,
      '스폰 남음: ${gameRef.spawner.remainingTotal}',
      Vector2(70, 18),
    );
    text.render(
      canvas,
      'Core HP: ${gameRef.coreHp.toInt()} / ${gameRef.coreMaxHp.toInt()}',
      Vector2(size.x - 150, 6),
    );
    if (gameRef.coreMaxShield > 0) {
      text.render(
        canvas,
        'Shield: ${gameRef.coreShield.toInt()}',
        Vector2(size.x - 150, 18),
      );
    }

    final ruleBg = Paint()..color = const Color(0xFF1B1F2A);
    final ruleBorder = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    final rect = _ruleButtonRect ?? Rect.fromLTWH(8, 32, 140, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(6)), ruleBorder);
    final ruleText = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 11,
        fontWeight: FontWeight.bold,
      ),
    );
    ruleText.render(canvas, '타겟팅: ${_ruleLabel(gameRef.currentRule)}', Vector2(rect.left + 8, rect.top + 4));

    final speedRect = _speedButtonRect ?? Rect.fromLTWH(160, 32, 70, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(speedRect, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(speedRect, const Radius.circular(6)), ruleBorder);
    ruleText.render(
      canvas,
      '${gameRef.timeScale == 1.0 ? '1x' : '2x'}',
      Vector2(speedRect.left + 24, speedRect.top + 4),
    );

    final dbg = _debugButtonRect ?? Rect.fromLTWH(size.x - 34, 32, 26, 22);
    canvas.drawRRect(RRect.fromRectAndRadius(dbg, const Radius.circular(6)), ruleBg);
    canvas.drawRRect(RRect.fromRectAndRadius(dbg, const Radius.circular(6)), ruleBorder);
    ruleText.render(canvas, 'DBG', Vector2(dbg.left + 2, dbg.top + 4));

    if (gameRef.debugOpen) {
      _renderDebugPanel(canvas);
    }
  }

  bool hitRuleButton(Vector2 worldPos) {
    if (_ruleButtonRect == null) return false;
    return _ruleButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitSpeedButton(Vector2 worldPos) {
    if (_speedButtonRect == null) return false;
    return _speedButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitDebugButton(Vector2 worldPos) {
    if (_debugButtonRect == null) return false;
    return _debugButtonRect!.contains(Offset(worldPos.x, worldPos.y));
  }

  bool hitDebugPanel(Vector2 worldPos, TowerDefenseGame game) {
    if (_debugPanelRect == null) return false;
    if (!_debugPanelRect!.contains(Offset(worldPos.x, worldPos.y))) return false;
    final local = Offset(worldPos.x - _debugPanelRect!.left, worldPos.y - _debugPanelRect!.top);
    final itemH = 24.0;
    final index = (local.dy / itemH).floor();
    switch (index) {
      case 0:
        game.debugInfiniteGold = !game.debugInfiniteGold;
        return true;
      case 1:
        game.debugSpawn('grunt_basic');
        return true;
      case 2:
        game.debugSpawn('sprinter_basic');
        return true;
      case 3:
        game.debugSpawn('tank_basic');
        return true;
      case 4:
        game.debugLevelUpTowers();
        return true;
      case 5:
        game._setSpeed(1.0);
        return true;
      case 6:
        game._setSpeed(2.0);
        return true;
      case 7:
        game._setSpeed(4.0);
        return true;
      default:
        return true;
    }
  }

  void _renderDebugPanel(Canvas canvas) {
    final rect = _debugPanelRect ?? Rect.fromLTWH(size.x - 190, 60, 180, 180);
    final bg = Paint()..color = const Color(0xCC0B0B12);
    final border = Paint()
      ..color = const Color(0xFF2B7FFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), bg);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), border);

    final items = [
      '무한 골드: ${gameRef.debugInfiniteGold ? 'ON' : 'OFF'}',
      '적 소환: Grunt',
      '적 소환: Sprinter',
      '적 소환: Tank',
      '타워 즉시 레벨업',
      '속도 1x',
      '속도 2x',
      '속도 4x',
    ];

    final text = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 11,
      ),
    );
    for (int i = 0; i < items.length; i++) {
      text.render(canvas, items[i], Vector2(rect.left + 8, rect.top + 4 + i * 24));
    }
  }

  String _ruleLabel(TargetingRule rule) {
    return switch (rule) {
      TargetingRule.nearest => '가까운 적',
      TargetingRule.farthestProgress => '진행도 우선',
      TargetingRule.highestHp => '높은 HP',
      TargetingRule.lowestHp => '낮은 HP',
    };
  }
}

class Tower extends PositionComponent {
  final TowerDefenseGame gameRef;
  final String towerId;
  final GridPoint grid;
  final TowerDef def;

  late double range;
  late double damage;
  late double fireRate;
  late Paint paint;
  Sprite? leftDownSprite;
  Sprite? rightDownSprite;
  Sprite? currentSprite;
  bool flipY = false;

  double cooldown = 0;
  late final TowerRuntimeState state;

  Tower({
    required this.gameRef,
    required this.towerId,
    required this.grid,
    required this.def,
  }) {
    final tile = gameRef.tileSize;
    size = Vector2(tile * 1.5, tile * 1.5);
    anchor = Anchor.center;
    updateWorldPosition();

    final permanentLevel = gameRef._getTowerPermanentLevel(def.id);
    state = TowerRuntimeState(
      initialCost: def.buildCost,
      permanentLevel: permanentLevel,
      growthConfig: gameRef.balanceConfig.growthForTower(def.id),
    );
    _applyStatsFromState();
    paint = Paint()..color = _rarityColor(def.rarity);
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    final path = _towerSpritePath(towerId);
    if (path == null) return;
    try {
      final image = await gameRef.images.load(path);
      final sheet = SpriteSheet.fromColumnsAndRows(image: image, columns: 2, rows: 1);
      // frame 0: left-down, frame 1: right-down (assumed)
      leftDownSprite = sheet.getSprite(0, 0);
      rightDownSprite = sheet.getSprite(0, 1);
      currentSprite = rightDownSprite;
      flipY = false;
    } catch (_) {
      leftDownSprite = null;
      rightDownSprite = null;
      currentSprite = null;
    }
  }

  void updateWorldPosition() {
    position = grid.toWorld(gameRef);
  }

  void updateTower(double dt, List<Enemy> enemies) {
    cooldown -= dt;
    if (cooldown > 0) return;

    final target = _findTarget(enemies);
    if (target == null) {
      _resetFacing();
      return;
    }
    _updateFacing(target.position - position);

    if (def.attackType == 'projectile') {
      final projectile = Projectile(
        gameRef: gameRef,
        origin: position.clone(),
        target: target,
        targetPos: target.position.clone(),
        damage: damage,
        speed: def.projectileSpeed,
        sizePx: def.projectileSize,
      );
      gameRef.add(projectile);
    } else {
      gameRef.add(HitscanEffect(
        start: position.clone(),
        end: target.position.clone(),
      ));
      target.takeDamage(damage);
    }
    cooldown = fireRate;
  }

  int get nextUpgradeCost {
    final multiplier = 1.0 + (state.level * def.upgradeCostMultiplier);
    return (def.upgradeCostBase * multiplier).round();
  }

  int get sellRefund {
    return (state.totalSpent * def.sellRefundRate).round();
  }

  void upgrade() {
    final cost = nextUpgradeCost;
    state.upgrade(cost: cost);
    _applyStatsFromState();
  }

  void cycleModule() {
    final values = TacticalModule.values;
    final nextIndex = (state.module.index + 1) % values.length;
    state.setModule(values[nextIndex]);
    _applyStatsFromState();
  }

  Enemy? _findTarget(List<Enemy> enemies) {
    final inRange = <Enemy>[];
    for (final enemy in enemies) {
      if (enemy.isRemoved) continue;
      if (enemy.position.distanceTo(position) <= range) {
        inRange.add(enemy);
      }
    }
    if (inRange.isEmpty) return null;

    switch (gameRef.currentRule) {
      case TargetingRule.nearest:
        inRange.sort((a, b) =>
            a.position.distanceTo(position).compareTo(b.position.distanceTo(position)));
        break;
      case TargetingRule.farthestProgress:
        inRange.sort((a, b) => b.progress.compareTo(a.progress));
        break;
      case TargetingRule.highestHp:
        inRange.sort((a, b) => b.hp.compareTo(a.hp));
        break;
      case TargetingRule.lowestHp:
        inRange.sort((a, b) => a.hp.compareTo(b.hp));
        break;
    }

    return inRange.first;
  }

  @override
  void render(Canvas canvas) {
    if (currentSprite != null) {
      canvas.save();
      if (flipY) {
        canvas.translate(0, size.y);
        canvas.scale(1.0, -1.0);
      }
      currentSprite!.render(
        canvas,
        position: Vector2.zero(),
        size: size,
      );
      canvas.restore();
    } else {
      final rect = Rect.fromLTWH(0, 0, size.x, size.y);
      canvas.drawRect(rect, paint);

      final barrelPaint = Paint()..color = const Color(0xFF1C1C1C);
      canvas.drawRect(Rect.fromLTWH(size.x / 2 - 4, 0, 8, 12), barrelPaint);
    }

    final levelText = TextPaint(
      style: const TextStyle(
        color: Colors.white,
        fontSize: 10,
        fontWeight: FontWeight.bold,
      ),
    );
    levelText.render(canvas, 'Lv${state.level}', Vector2(2, -14));

    final statText = TextPaint(
      style: const TextStyle(
        color: Color(0xFFB5B5C0),
        fontSize: 8,
      ),
    );
    statText.render(
      canvas,
      'D${damage.toStringAsFixed(0)} F${fireRate.toStringAsFixed(2)} R${range.toStringAsFixed(0)}',
      Vector2(0, size.y + 2),
    );
  }

  void _updateFacing(Vector2 dir) {
    if (rightDownSprite == null || leftDownSprite == null) return;
    if (dir.x >= 0) {
      currentSprite = rightDownSprite;
    } else {
      currentSprite = leftDownSprite;
    }
    flipY = dir.y < 0;
  }

  void _resetFacing() {
    if (rightDownSprite == null) return;
    currentSprite = rightDownSprite;
    flipY = false;
  }


  void _applyStatsFromState() {
    final baseDamage = def.baseDamage * state.permanentDamageMultiplier;
    final baseFireRate = def.fireRate * state.permanentFireRateMultiplier;
    final baseRange = def.range + state.permanentRangeBonus;

    damage = baseDamage * state.damageMultiplier * state.moduleDamageMultiplier;
    fireRate = (baseFireRate * state.fireRateMultiplier * state.moduleFireRateMultiplier)
        .clamp(0.15, 10.0);
    range = baseRange + state.rangeBonus + state.moduleRangeBonus;
  }
}

class TowerRuntimeState {
  int level = 1;
  int totalSpent = 0;
  double damageMultiplier = 1.0;
  double fireRateMultiplier = 1.0;
  double rangeBonus = 0;
  int permanentLevel = 1;
  double permanentDamageMultiplier = 1.0;
  double permanentFireRateMultiplier = 1.0;
  double permanentRangeBonus = 0;
  TacticalModule module = TacticalModule.none;
  double moduleDamageMultiplier = 1.0;
  double moduleFireRateMultiplier = 1.0;
  double moduleRangeBonus = 0;
  final PermanentGrowthConfig growthConfig;

  TowerRuntimeState({
    required int initialCost,
    required this.permanentLevel,
    required this.growthConfig,
  }) {
    totalSpent = initialCost;
    _applyPermanentLevel(permanentLevel);
  }

  void upgrade({required int cost}) {
    level += 1;
    totalSpent += cost;
    damageMultiplier *= 1.15;
    fireRateMultiplier *= 0.9;
    rangeBonus += 4;
  }

  void setModule(TacticalModule next) {
    module = next;
    moduleDamageMultiplier = 1.0;
    moduleFireRateMultiplier = 1.0;
    moduleRangeBonus = 0;

    switch (module) {
      case TacticalModule.none:
        break;
      case TacticalModule.focus:
        moduleDamageMultiplier = 1.5;
        break;
      case TacticalModule.overclock:
        moduleFireRateMultiplier = 1.6;
        break;
      case TacticalModule.range:
        moduleRangeBonus = 16;
        break;
    }
  }

  void _applyPermanentLevel(int level) {
    final lv = level.clamp(1, 10);
    final bonusLevel = lv - 1;
    permanentDamageMultiplier = 1.0 + bonusLevel * growthConfig.damagePercentPerLevel;
    permanentFireRateMultiplier = 1.0 + bonusLevel * growthConfig.fireRatePercentPerLevel;
    if (growthConfig.rangeBonusEveryLevels > 0) {
      permanentRangeBonus =
          bonusLevel >= growthConfig.rangeBonusEveryLevels
              ? growthConfig.rangeBonusPerStep *
                  (bonusLevel ~/ growthConfig.rangeBonusEveryLevels)
              : 0.0;
    } else {
      permanentRangeBonus = 0.0;
    }
  }
}

class SpawnController extends Component {
  final TowerDefenseGame game;
  WaveDef waveDef;
  double timer = 0;
  int index = 0;
  int remainingInEntry = 0;
  double nextSpawnAt = 0;
  bool paused = false;
  int remainingTotal = 0;

  SpawnController({required this.game, required this.waveDef});

  @override
  void onMount() {
    super.onMount();
    _recalculateRemaining();
  }

  @override
  void update(double dt) {
    if (paused) return;
    timer += dt;
    while (index < waveDef.spawns.length) {
      final entry = waveDef.spawns[index];
      if (remainingInEntry == 0) {
        if (timer < entry.at) {
          break;
        }
        remainingInEntry = entry.count;
        nextSpawnAt = timer;
      }

      if (timer >= nextSpawnAt) {
        game.spawnEnemyById(entry.enemyId);
        remainingInEntry--;
        if (remainingInEntry > 0) {
          nextSpawnAt += entry.intervalMs / 1000.0;
        } else {
          index++;
        }
        remainingTotal -= 1;
        continue;
      }
      break;
    }
  }

  void pauseSpawning() {
    paused = true;
  }

  bool get isFinished => index >= waveDef.spawns.length;

  void resetWith(WaveDef nextWave) {
    waveDef = nextWave;
    timer = 0;
    index = 0;
    remainingInEntry = 0;
    nextSpawnAt = 0;
    _recalculateRemaining();
  }

  void _recalculateRemaining() {
    remainingTotal = 0;
    for (final entry in waveDef.spawns) {
      remainingTotal += entry.count;
    }
  }
}

class _HudButtonData {
  final String towerId;
  final String label;
  final String name;
  final Color color;

  _HudButtonData(this.towerId, this.label, this.name, this.color);
}
